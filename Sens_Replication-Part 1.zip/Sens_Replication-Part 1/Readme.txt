

The code in this replication file allows for a complete replication of the analyses in our manuscript.  


Magnet Hospitals

We are unable to provide data for this analysis. Data are available from the states of PA, FL, and NY with an appropriate DUA. We include the R scripts we used for the analysis.

The scripts for each table or figure is in the primary directory. In the estimation directory, are a set of scripts that do various estimation steps. Those steps are

Weight-Estimates.R -- Estimates balancing weights for ATT and ATO estimands.
Outome_Est.R -- Estimates treatment effects for both outcomes.
Sensitivity-Analysis.R -- Computes sensitivity bounds for each outcome and estimand.
Sens-Benchmarks.R -- Computes differences in bounds after omitting each observed covariate.

Sims

These folders contain both the scripts to run the simulations and output from the simulations we used in the analysis.


