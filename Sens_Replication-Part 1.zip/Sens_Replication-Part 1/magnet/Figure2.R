

library(tidyverse)
library(dplyr)
library(foreign)
library(ggplot2)

rm(list = ls())

data <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

load("magnet-weights.RData")

# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$magnet_egs == 1] <- 1

summary(data$wts)
sum((data$wts>5))

data$max.wts <- bal.maxsubset$weights
data$max.wts[data$max.wts < 0] <- 0
summary(data$max.wts)

data.ctrl <- data %>% filter(magnet_egs==0)

h1 <- ggplot(data.ctrl, aes(wts)) +
   geom_histogram( bins = 50, color="black", fill="lightblue") + theme_bw() +
    ylab("Number of Occurrences") +
    scale_x_continuous("ATT Weights")
h1

h2 <- ggplot(data, aes(max.wts)) +
   geom_histogram( bins = 50, color="black", fill="lightblue") + theme_bw() +
    ylab("Number of Occurrences") +
    scale_x_continuous("ATO Weights") 
h2

library(gridExtra)

## Figure 2
pdf("weight-hist.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(h1, h2, nrow=1, widths = c(1,1))
dev.off() 
