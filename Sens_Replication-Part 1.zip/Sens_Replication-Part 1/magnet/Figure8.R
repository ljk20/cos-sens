
library(metR)
library(dplyr)
library(ggplot2)
library(gridExtra)

rm(list=ls())

amplify_R2<-function(R2){
  R2_U = seq(0, 1, by = 0.1)
  R2_V = seq(0, 1, by = 0.1)
  data.r2 = expand.grid(R2_U, R2_V)
  names(data.r2) = c("R2_U", "R2_V")
  data.r2 = data.r2 |> dplyr::mutate(R2 = 1-(1-R2_V)*(1-R2_U))
  return(data.r2)
}

data.r2 = amplify_R2()

load("ato-sens-benchmark.RData")

round(ato.bchmk.1, 3)

#GENERATE BENCHMARKING RESULTS - How Calc fo Each Cov
fake_benchmark_ato <- data.frame(
  R2_V_hat = c(0.31, 0.14, 0.15, 0, .15), 
  R2_U_hat = c(0, 0, 0, 0.004, .004), 
  covariate = c("No. Patients", "No. Patients Sqd.", "% Cases Surgery", "Transfer", "% Cases Surgery and Transfer")
)

#Threshold sensitivity parameter where interval contains zero 
R2_threshold = 0.2

ato.p <- data.r2 |> ggplot(aes(x = R2_U, y = R2_V, z = R2)) + geom_contour(col= 'black') + 
  geom_contour(breaks = R2_threshold, size=2.5, linetype=3, col='black') + 
  theme_classic() + xlab(expression(R[U]^2)) + ylab(expression(R[V]^2)) + 
  xlim(c(0, 0.5)) +  ylim(c(0, 0.5)) +
  metR::geom_text_contour(aes(z = R2)) + 
  geom_point(data = fake_benchmark_ato, aes(x = R2_U_hat, y = R2_V_hat, z = NULL), size = 2, col = "black")   +
  ggrepel::geom_label_repel(data = fake_benchmark_ato, aes(x = R2_U_hat, y = R2_V_hat, z = NULL, label = covariate), 
                            box.padding = 0.5, point.padding = 0.5, segment.color = 'black')
  
ato.p

load("att-sens-benchmark.RData")

round(att.bchmk.2, 3)

fake_benchmark_att <- data.frame(
  R2_V_hat = c(0.17, 0.18, 0.06, 0, .06), 
  R2_U_hat = c(0, 0, 0, 0.21, .21), 
  covariate = c("No. Patients", "No. Patients Sqd.", "% Cases Surgery", "Transfer", "% Cases Surgery and Transfer")
)

R2_threshold = 0.3

att.p <- data.r2 |> ggplot(aes(x = R2_U, y = R2_V, z = R2)) + geom_contour(col= 'black') + 
  geom_contour(breaks = R2_threshold, size=2.5, linetype=3, col='black') + 
  theme_classic() + xlab(expression(R[U]^2)) + ylab(expression(R[V]^2)) + 
  xlim(c(0, 0.5)) +  ylim(c(0, 0.5)) +
  metR::geom_text_contour(aes(z = R2)) + 
  geom_point(data = fake_benchmark_att, aes(x = R2_U_hat, y = R2_V_hat, z = NULL), size = 2, col = "black")   +
  ggrepel::geom_label_repel(data = fake_benchmark_att, aes(x = R2_U_hat, y = R2_V_hat, z = NULL, label = covariate), 
                            box.padding = 0.5, point.padding = 0.5, segment.color = 'black')

att.p

## Figure 8

pdf("sens-amp.pdf", width=11, height=5, onefile=FALSE, paper="special")
grid.arrange(att.p, ato.p, nrow=1, widths = c(1,1))
dev.off() 

