
library(foreign)
library(balancer)
library(lme4)
library(sjstats)
library(ICC)

rm(list = ls())

data <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

pat.cov <- c("age", "comorb", "female",
           "angus", "disability_bin", "surg2", "transfer",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51")            
hosp.cov <- c("n_pats", "n_pats_sq", "st_trauma", "p_surg", "p_emerg", "p_medicaid")

## Hyperparameter Selection
all_covs_form <- paste(paste(pat.cov, collapse = "+"), "+", paste(hosp.cov, collapse = "+"))

 # timing
t_fexact <- system.time({ 
	
fit.lmer <- lmer(as.formula(paste("adverse ~ ", all_covs_form, "+ ( 1 | hospid)")), data)

})

# time required for computation, in minutes
t_fexact[['elapsed']]/60


fit_icc <- performance::icc(fit.lmer)$ICC_adjusted
fit_var <- summary(fit.lmer)$sigma ^ 2
fit_beta_norm <- sqrt(sum(coef(fit.lmer)$hospid[1,-1]^2))
fit_lambda <- fit_var / fit_beta_norm^2

fit_icc
fit_lambda

save(fit_icc, fit_lambda, file="hyperparameter.RData")
             
pat_covs <- scale(data[,pat.cov])
hosp_covs <- scale(data[,hosp.cov])

bal.wts <- cluster_weights(pat_covs, hosp_covs , data$magnet_egs,
                        data$hospid, lambda = fit_lambda, icc = fit_icc,
                        lowlim = 0, uplim = 1)

bal.maxsubset <- maxsubset_weights_cluster(pat_covs, hosp_covs, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)
                                                                                                                                                                                                  
save(bal.wts, bal.maxsubset, file="magnet-weights.RData")



