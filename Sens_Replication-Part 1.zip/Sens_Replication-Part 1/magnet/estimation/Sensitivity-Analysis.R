
library(foreign)
library(balancer)
library(lme4)
library(sjstats)
library(ICC)
library(tidyverse)
library(CVXR)

rm(list = lsdata <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

load("magnet-weights.RData")
source('sens-funcs.R')

# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$magnet_egs == 1] <- 1
data$weights = data$wts
summary(data$wts)

data$weights[data$magnet_egs==0] <- data$weights[data$magnet_egs==0]/mean(data$weights[data$magnet_egs==0])
summary(data$weights)

#RUN SENSITIVITY:

# ATT Estimand

# Marginal Model
att_bounds_msm_a <- estimate_msm_bounds(seq(1, 1.2, by =0.02), data$weights, data$magnet_egs, data$adverse, type = "ATT")
lambda <- seq(1, 1.2, by =0.02)
rownames(att_bounds_msm_a) <- lambda
## Adverse
att_bounds_msm_a

att_bounds_msm_f <- estimate_msm_bounds(seq(1, 1.9, by =0.1), data$weights, data$magnet_egs, data$ftr, type = "ATT")
lambda <- seq(1, 1.9, by =0.1)
rownames(att_bounds_msm_f) <- lambda
## FTR
att_bounds_msm_f   

# Variance Model  
att_bounds_vbm_a <- estimate_vbm_bounds(seq(0, 0.1, by = 0.01), data$weights, data$magnet_egs, data$adverse, type = "ATT")
r2 <- seq(0, 0.1, by = 0.01)
rownames(att_bounds_vbm_a) <- r2
## Adverse Events
att_bounds_vbm_a


att_bounds_vbm_f <- estimate_vbm_bounds(seq(0, 0.5, by = 0.1), data$weights, data$magnet_egs, data$ftr, type = "ATT")
r2 <- seq(0, 0.5, by = 0.1)
rownames(att_bounds_vbm_f) <- r2
## FTR
att_bounds_vbm_f

save(att_bounds_msm_a, att_bounds_msm_f,
     att_bounds_vbm_a, att_bounds_vbm_f, file="att-sens-out.RData")

#-------------------------------------------------
## Overlap Weights Version


data$max.wts <- bal.maxsubset$weights
data$max.wts[data$max.wts < 0] <- 0
summary(data$max.wts)

# ATO Estimand

# Marginal Model
ato_bounds_msm_a <- estimate_msm_bounds(seq(1, 1.2, by = 0.02), data$max.wts, data$magnet_egs, data$adverse, type = "ATO")
lambda <- seq(1, 1.2, by =0.02)
rownames(ato_bounds_msm_a) <- lambda
## Adverse
ato_bounds_msm_a 

ato_bounds_msm_f <- estimate_msm_bounds(seq(1, 1.5, by =0.1), data$max.wts, data$magnet_egs, data$ftr, type = "ATO")
lambda <- seq(1, 1.5, by =0.1)
rownames(ato_bounds_msm_f) <- lambda
## FTR
ato_bounds_msm_f

# Variance Model  
ato_bounds_vbm_a <- estimate_vbm_bounds(seq(0, 0.1, by = 0.01), data$max.wts, data$magnet_egs, data$adverse, type = "ATO")
r2 <- seq(0, 0.1, by = 0.01)
rownames(ato_bounds_vbm_a) <- r2
## Adverse Events
ato_bounds_vbm_a

ato_bounds_vbm_f <- estimate_vbm_bounds(seq(0, 0.5, by = 0.1), data$max.wts, data$magnet_egs, data$ftr, type = "ATO")
r2 <- seq(0, 0.5, by = 0.1)
rownames(ato_bounds_vbm_f) <- r2
## FTR
ato_bounds_vbm_f

save(ato_bounds_msm_a, ato_bounds_msm_f,
     ato_bounds_vbm_a, ato_bounds_vbm_f, file="ato-sens-out.RData")
     
                       