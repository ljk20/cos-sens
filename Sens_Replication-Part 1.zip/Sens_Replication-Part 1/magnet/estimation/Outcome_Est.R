

library(tidyverse)
library(foreign)
require(sandwich, quietly = TRUE)
require(lmtest, quietly = TRUE)
library(balancer)

rm(list=ls())

data <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

load("magnet-weights.RData")

cl   <- function(dat,fm, cluster){
           M <- length(unique(cluster))
           N <- length(cluster)
           K <- fm$rank
           dfc <- (M/(M-1))*((N-1)/(N-K))
           uj  <- apply(estfun(fm),2, function(x) tapply(x, cluster, sum));
           vcovCL <- dfc*sandwich(fm, meat=crossprod(uj)/N)
           coeftest(fm, vcovCL) }

# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$magnet_egs == 1] <- 1
summary(data$wts)

data$max.wts <- bal.maxsubset$weights
data$max.wts[data$max.wts < 0] <- 0
summary(data$max.wts)

all.cov <- c("comorb", "female",
          "angus", "disability_bin", "surg2", "transfer",
           "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51", "n_pats", "n_pats_sq", 
           "st_trauma", "p_surg", "p_emerg", "p_medicaid")

             
# reformulate(all.cov)            
## Outcome Estimates
## Unadjusted
fit0 <- lm(adverse ~ magnet_egs, data = data)
unadj.a <- cl(data, fit0, cluster = data$hospid)          

fit1 <- lm(ftr_i ~ magnet_egs, data = data)
unadj.f <- cl(data, fit1, cluster = data$hospid)


## Balancing Weights

## Adverse Events
fit_0 <- lm(adverse ~ age + comorb + female + angus + disability_bin + surg2 + transfer + 
    p_cat2 + p_cat3 + p_cat4 + p_cat5 + ynel2 + ynel3 + ynel4 + 
    ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + ynel11 + 
    ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + ynel18 + 
    ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + ynel25 + 
    ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + ynel31 + shafi2 + 
    shafi3 + shafi4 + shafi5 + shafi6 + shafi7 + shafi8 + shafi9 + 
    shafi10 + shafi11 + shafi12 + shafi13 + shafi14 + shafi15 + 
    shafi16 + shafi17 + shafi18 + shafi19 + shafi20 + shafi21 + 
    shafi22 + shafi23 + shafi24 + shafi25 + shafi26 + shafi27 + 
    shafi28 + shafi29 + shafi30 + shafi31 + shafi32 + shafi33 + 
    shafi34 + shafi35 + shafi36 + shafi37 + shafi38 + shafi39 + 
    shafi40 + shafi41 + shafi42 + shafi43 + shafi44 + shafi45 + 
    shafi46 + shafi47 + shafi48 + shafi49 + shafi50 + shafi51 + 
    n_pats + n_pats_sq + st_trauma + p_surg + p_emerg + p_medicaid, 
                         data=data[data$magnet_egs == 0,])
                         

fit_1 <- lm(adverse ~ age + comorb + female + angus + disability_bin + surg2 + transfer + 
    p_cat2 + p_cat3 + p_cat4 + p_cat5 + ynel2 + ynel3 + ynel4 + 
    ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + ynel11 + 
    ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + ynel18 + 
    ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + ynel25 + 
    ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + ynel31 + shafi2 + 
    shafi3 + shafi4 + shafi5 + shafi6 + shafi7 + shafi8 + shafi9 + 
    shafi10 + shafi11 + shafi12 + shafi13 + shafi14 + shafi15 + 
    shafi16 + shafi17 + shafi18 + shafi19 + shafi20 + shafi21 + 
    shafi22 + shafi23 + shafi24 + shafi25 + shafi26 + shafi27 + 
    shafi28 + shafi29 + shafi30 + shafi31 + shafi32 + shafi33 + 
    shafi34 + shafi35 + shafi36 + shafi37 + shafi38 + shafi39 + 
    shafi40 + shafi41 + shafi42 + shafi43 + shafi44 + shafi45 + 
    shafi46 + shafi47 + shafi48 + shafi49 + shafi50 + shafi51 + 
    n_pats + n_pats_sq + st_trauma + p_surg + p_emerg + p_medicaid,  
                         data=data[data$magnet_egs == 1,])
                         
m0hat <- predict(fit_0, data)
m1hat <- predict(fit_1, data)
se.out.a <- compute_cluster_se(data$adverse, data$wts, data$magnet_egs, data$hospid, m1hat, m0hat)
se.out.a 
                                                                           
adjust.vars <- c("magnet_egs")
adv.full <- lm(reformulate(adjust.vars, response="adverse"), data=data, weights = wts)
msm.a <- cl(data, adv.full, cluster = data$hospid)
msm.a

adjust.vars <- c("magnet_egs", all.cov)
adv.full <- lm(reformulate(adjust.vars, response="adverse"), data=data, weights = wts)
bias.adj.a <- cl(data, adv.full, cluster = data$hospid)
bias.adj.a[2,]

se.out.a.mx <- compute_cluster_maxsubset_se(data$adverse, data$max.wts, data$magnet_egs, data$hospid, m1hat, m0hat)
se.out.a.mx

adjust.vars <- c("magnet_egs")
adv.ato <- lm(reformulate(adjust.vars, response="adverse"), data=data, weights = max.wts)
ato.msm.a <- cl(data, adv.ato, cluster = data$hospid)
ato.msm.a

## FTR

fit_0 <- lm(ftr ~ age + comorb + female + angus + disability_bin + surg2 + transfer + 
    p_cat2 + p_cat3 + p_cat4 + p_cat5 + ynel2 + ynel3 + ynel4 + 
    ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + ynel11 + 
    ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + ynel18 + 
    ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + ynel25 + 
    ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + ynel31 + shafi2 + 
    shafi3 + shafi4 + shafi5 + shafi6 + shafi7 + shafi8 + shafi9 + 
    shafi10 + shafi11 + shafi12 + shafi13 + shafi14 + shafi15 + 
    shafi16 + shafi17 + shafi18 + shafi19 + shafi20 + shafi21 + 
    shafi22 + shafi23 + shafi24 + shafi25 + shafi26 + shafi27 + 
    shafi28 + shafi29 + shafi30 + shafi31 + shafi32 + shafi33 + 
    shafi34 + shafi35 + shafi36 + shafi37 + shafi38 + shafi39 + 
    shafi40 + shafi41 + shafi42 + shafi43 + shafi44 + shafi45 + 
    shafi46 + shafi47 + shafi48 + shafi49 + shafi50 + shafi51 + 
    n_pats + n_pats_sq + st_trauma + p_surg + p_emerg + p_medicaid, 
                         data=data[data$magnet_egs==0,])

fit_1 <- lm(ftr ~ age + comorb + female + angus + disability_bin + surg2 + transfer + 
    p_cat2 + p_cat3 + p_cat4 + p_cat5 + ynel2 + ynel3 + ynel4 + 
    ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + ynel11 + 
    ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + ynel18 + 
    ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + ynel25 + 
    ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + ynel31 + shafi2 + 
    shafi3 + shafi4 + shafi5 + shafi6 + shafi7 + shafi8 + shafi9 + 
    shafi10 + shafi11 + shafi12 + shafi13 + shafi14 + shafi15 + 
    shafi16 + shafi17 + shafi18 + shafi19 + shafi20 + shafi21 + 
    shafi22 + shafi23 + shafi24 + shafi25 + shafi26 + shafi27 + 
    shafi28 + shafi29 + shafi30 + shafi31 + shafi32 + shafi33 + 
    shafi34 + shafi35 + shafi36 + shafi37 + shafi38 + shafi39 + 
    shafi40 + shafi41 + shafi42 + shafi43 + shafi44 + shafi45 + 
    shafi46 + shafi47 + shafi48 + shafi49 + shafi50 + shafi51 + 
    n_pats + n_pats_sq + st_trauma + p_surg + p_emerg + p_medicaid, 
                         data=data[data$magnet_egs==1,])

m0hat <- predict(fit_0, data)
m1hat <- predict(fit_1, data)
se.out.f <- compute_cluster_se(data$ftr, data$wts, data$magnet_egs, data$hospid, m1hat, m0hat)
se.out.f

adjust.vars <- c("magnet_egs")
ftr.full <- lm(reformulate(adjust.vars, response="ftr"), data=data, weights = wts)
msm.f <- cl(data, ftr.full, cluster = data$hospid)
msm.f

adjust.vars <- c("magnet_egs", all.cov)
ftr.full <- lm(reformulate(adjust.vars, response="ftr"), data=data, weights = wts)
bias.adj.f <- cl(data, ftr.full, cluster = data$hospid)
bias.adj.f[2,]

se.out.f.mx <- compute_cluster_maxsubset_se(data$ftr, data$max.wts, data$magnet_egs, data$hospid, m1hat, m0hat)
se.out.f.mx

adjust.vars <- c("magnet_egs")
ftr.full <- lm(reformulate(adjust.vars, response="ftr"), data=data, weights = max.wts)
ato.msm.f <- cl(data, ftr.full, cluster = data$hospid)
ato.msm.f


save(unadj.a, unadj.f,
     se.out.a, se.out.f, 
     msm.a, msm.f,
     bias.adj.a, bias.adj.f, 
     se.out.a.mx, se.out.f.mx, 
     ato.msm.a, ato.msm.f,
     file="magnet_estimates.RData")
    