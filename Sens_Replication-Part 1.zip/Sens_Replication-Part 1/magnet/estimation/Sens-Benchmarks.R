library(tidyverse)
library(foreign)
require(sandwich, quietly = TRUE)
require(lmtest, quietly = TRUE)
library(balancer)

rm(list=ls())

data <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

load("magnet-weights.RData")
load("hyperparameter.RData")

# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$magnet_egs == 1] <- 1
data$weights = data$wts
summary(data$wts)

data$orcle.weights[data$magnet_egs==0] <- data$weights[data$magnet_egs==0]/mean(data$weights[data$magnet_egs==0])
summary(data$orcle.weights)

pat.cov <- c("transfer","surg2", "age", "comorb", "female",
             "angus", "disability_bin",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51")            
hosp.cov <- c("n_pats", "n_pats_sq", "st_trauma", "p_surg", "p_emerg", "p_medicaid")

  #-------------------------------------------------
# Benchmarking

benchmarking<-function(weights_omit, weights){
  R2_hat = 1-var(weights_omit)/var(weights)
  return(data.frame(R2_benchmark = R2_hat/(1+R2_hat), R2_hat = R2_hat))
}

k <- length(hosp.cov)

bnames <- c("R2_benchmark","R2_hat")

att.bchmk.1 <- matrix(NA, (k+2), 2)
att.bchmk.2 <- matrix(NA, (k+2), 2)

for(i in 1:k){
hosp.cov.o <- hosp.cov[-i]	
	
pat_covs <- scale(data[,pat.cov])
hosp_covs_o <- scale(data[,hosp.cov.o])

bal.omit <- cluster_weights(pat_covs, hosp_covs_o , data$magnet_egs,
                        data$hospid, lambda = fit_lambda, icc = fit_icc,
                        lowlim = 0, uplim = 1, verbose = FALSE)
                       
data$o.wts <- pmax(bal.omit$weights, 0)
data$o.wts[data$magnet_egs == 1] <- 1
data$weights_omit <- data$o.wts
data$weights_omit[data$magnet_egs==0] <- data$weights_omit[data$magnet_egs==0]/mean(data$weights_omit[data$magnet_egs==0])

att.bchmk.1[i,] <- unlist(benchmarking(data$weights_omit[data$magnet_egs==0], data$orcle.weights[data$magnet_egs==0]))
att.bchmk.2[i,] <- unlist(benchmarking(data$orcle.weights[data$magnet_egs==0], data$weights_omit[data$magnet_egs==0]))
	
}


## Omit Patient Covs
pat.cov.o <- pat.cov[-1] 	
pat_covs <- scale(data[,pat.cov.o])
hosp_covs <- scale(data[,hosp.cov])

bal.omit1 <- cluster_weights(pat_covs, hosp_covs, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)

                       
data$o.wts <- pmax(bal.omit1$weights, 0)
data$o.wts[data$magnet_egs == 1] <- 1
data$weights_omit <- data$o.wts
data$weights_omit[data$magnet_egs==0] <- data$weights_omit[data$magnet_egs==0]/mean(data$weights_omit[data$magnet_egs==0])

att.bchmk.1[(k+1),] <- unlist(benchmarking(data$weights_omit[data$magnet_egs==0], data$orcle.weights[data$magnet_egs==0]))
att.bchmk.2[(k+1),] <- unlist(benchmarking(data$orcle.weights[data$magnet_egs==0], data$weights_omit[data$magnet_egs==0]))

## Omit Both Covs

pat.cov.o <- pat.cov[-1] 	
pat_covs <- scale(data[,pat.cov.o])
hosp.cov.o <- hosp.cov[-4]
hosp_covs <- scale(data[,hosp.cov.o])

bal.omit2 <- cluster_weights(pat_covs, hosp_covs, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)

                       
data$o.wts <- pmax(bal.omit2$weights, 0)
data$o.wts[data$magnet_egs == 1] <- 1
data$weights_omit <- data$o.wts
data$weights_omit[data$magnet_egs==0] <- data$weights_omit[data$magnet_egs==0]/mean(data$weights_omit[data$magnet_egs==0])

att.bchmk.1[(k+2),] <- unlist(benchmarking(data$weights_omit[data$magnet_egs==0], data$orcle.weights[data$magnet_egs==0]))
att.bchmk.2[(k+2),] <- unlist(benchmarking(data$orcle.weights[data$magnet_egs==0], data$weights_omit[data$magnet_egs==0]))

names.f <- c(hosp.cov, "transfer", "both")
rownames(att.bchmk.1) <- names.f
colnames(att.bchmk.1) <- bnames
rownames(att.bchmk.2) <- names.f
colnames(att.bchmk.2) <- bnames

att.bchmk.1
att.bchmk.2

save(att.bchmk.1, att.bchmk.2, file="att-sens-benchmark.RData")

## Overlap Weights Version
ato.bchmk.1 <- matrix(NA, (k+2), 2)
ato.bchmk.2 <- matrix(NA, (k+2), 2)

data$mx.orcle.weights <- bal.maxsubset$weights
data$mx.orcle.weights[data$mx.orcle.weights < 0] <- 0


for(i in 1:k){
	
hosp.cov.o <- hosp.cov[-i]	
	
pat_covs <- scale(data[,pat.cov])
hosp_covs_o <- scale(data[,hosp.cov.o])

bal.omit.maxsubset <- maxsubset_weights_cluster(pat_covs, hosp_covs_o, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)

                       
data$o.mx.wts <- pmax(bal.omit.maxsubset$weights, 0)
data$o.mx.wts[data$o.mx.wts < 0] <- 0

ato.bchmk.1[i,] <- unlist(benchmarking(data$o.mx.wts[data$magnet_egs==0], data$mx.orcle.weights[data$magnet_egs==0]))
ato.bchmk.2[i,] <- unlist(benchmarking(data$mx.orcle.weights[data$magnet_egs==0], data$o.mx.wts[data$magnet_egs==0]))
	
}

## Omit Patient Covs
pat.cov.o <- pat.cov[-1] 	
pat_covs <- scale(data[,pat.cov.o])
hosp_covs <- scale(data[,hosp.cov])

bal.omit.maxsubset1 <- maxsubset_weights_cluster(pat_covs, hosp_covs, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)

                       
data$o.mx.wts <- pmax(bal.omit.maxsubset1$weights, 0)
data$o.mx.wts[data$o.mx.wts < 0] <- 0

ato.bchmk.1[k+1,] <- unlist(benchmarking(data$o.mx.wts[data$magnet_egs==0], data$mx.orcle.weights[data$magnet_egs==0]))
ato.bchmk.2[k+1,] <- unlist(benchmarking(data$mx.orcle.weights[data$magnet_egs==0], data$o.mx.wts[data$magnet_egs==0]))

## Omit Both Covs

pat.cov.o <- pat.cov[-1] 	
pat_covs <- scale(data[,pat.cov.o])
hosp.cov.o <- hosp.cov[-4]
hosp_covs <- scale(data[,hosp.cov.o])

bal.omit.maxsubset2 <- maxsubset_weights_cluster(pat_covs, hosp_covs, data$magnet_egs,
                         data$hospid, lambda = fit_lambda, icc = fit_icc,
                         lowlim = 0, uplim = 1)

                       
data$o.mx.wts <- pmax(bal.omit.maxsubset2$weights, 0)
data$o.mx.wts[data$o.mx.wts < 0] <- 0

ato.bchmk.1[(k+2),] <- unlist(benchmarking(data$o.mx.wts[data$magnet_egs==0], data$mx.orcle.weights[data$magnet_egs==0]))
ato.bchmk.2[(k+2),] <- unlist(benchmarking(data$mx.orcle.weights[data$magnet_egs==0], data$o.mx.wts[data$magnet_egs==0]))

names.f <- c(hosp.cov, "transfer", "both")
rownames(ato.bchmk.1) <- names.f
colnames(ato.bchmk.1) <- bnames
rownames(ato.bchmk.2) <- names.f
colnames(ato.bchmk.2) <- bnames

ato.bchmk.1
ato.bchmk.2

save(ato.bchmk.1, ato.bchmk.2, file="ato-sens-benchmark.RData")




