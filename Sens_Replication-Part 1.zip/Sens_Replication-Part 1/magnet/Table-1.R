


rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Magnet/routput")
load("magnet_estimates.RData")

## Unadjusted
unadj.a[2,]
unadj.f[2,]

crit <- qt(1 - (1- 0.95)/2, df = Inf)

## Standard COS Weights

round(msm.f[2,], 4)

round(msm.a[2,], 4)

## Bias Adjusted
out1 <- unlist(c(se.out.f[3,2], (se.out.f[3,2] - se.out.f[3,3] * crit), (se.out.f[3,2] + se.out.f[3,3] * crit)))
out1
2 * pt(abs(se.out.f[3,2]/se.out.f[3,3]), df=Inf, lower.tail = FALSE)

out2 <- unlist(c(se.out.a[3,2], (se.out.a[3,2] - se.out.a[3,3] * crit), (se.out.a[3,2] + se.out.a[3,3] * crit)))
out2*100
2 * pt(abs(se.out.a[3,2]/se.out.a[3,3]), df=Inf, lower.tail = FALSE)


## Bias Adjusted
round(bias.adj.f[2,], 4)

round(bias.adj.a[2,], 4)

## Subset Wts
out1 <- unlist(c(ato.msm.f[2,1], (ato.msm.f[2,1] - ato.msm.f[2,2] * crit), (ato.msm.f[2,1] + ato.msm.f[2,2] * crit)))
out1
2 * pt(abs(ato.msm.f[2,1]/ato.msm.f[2,2]), df=Inf, lower.tail = FALSE)


out2 <- unlist(c(ato.msm.a[2,1], (ato.msm.a[2,1] - ato.msm.a[2,2] * crit), (ato.msm.a[2,1] + ato.msm.a[2,2] * crit)))
out2
2 * pt(abs(ato.msm.a[2,1]/ato.msm.a[2,2]), df=Inf, lower.tail = FALSE)