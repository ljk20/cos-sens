

library(tidyverse)
library(dplyr)
library(foreign)
library(ggplot2)

rm(list = ls())

data <- read.dta("magnet-cos.dta")
data$n_pats_sq <- data$n_pats^2

load("magnet-weights.RData")

# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$magnet_egs == 1] <- 1

summary(data$wts)
sum((data$wts>5))

data$max.wts <- bal.maxsubset$weights
data$max.wts[data$max.wts < 0] <- 0
summary(data$max.wts)


## Balance
all.cov <- c("age","comorb", "female",
           "angus", "disability_bin", "surg2", "transfer",
           "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "n_pats", "n_pats_sq", 
           "st_trauma", "p_surg", "p_emerg", "p_medicaid")

             
data.var <- data %>% group_by(magnet_egs) %>% 
   summarize(across(all_of(all.cov), ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))

um.wt <- data %>% group_by(magnet_egs) %>% 
   summarize(across(all_of(all.cov), ~mean(.x))) %>% as.data.frame()

bal.0 <- data %>% group_by(magnet_egs) %>% 
   summarize(across(all_of(all.cov), ~ weighted.mean(.x, wts))) %>% as.data.frame()
   
bal.max <- data %>% group_by(magnet_egs) %>% 
   summarize(across(all_of(all.cov), ~ weighted.mean(.x, max.wts))) %>% as.data.frame()   
   
um.wt.tab <- matrix(NA, length(all.cov), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.sd

bal.0.tab <- matrix(NA, length(all.cov), 3)
bal.0.tab[,1] <- unlist(bal.0[1,-1]) 
bal.0.tab[,2] <- unlist(bal.0[2,-1])                        
bal.0.tab[,3] <- (unlist(bal.0[2,-1]) - unlist(bal.0[1,-1]))/pooled.sd
             
bal.max.tab <- matrix(NA, length(all.cov), 3)
bal.max.tab[,1] <- unlist(bal.max[1,-1]) 
bal.max.tab[,2] <- unlist(bal.max[2,-1])                        
bal.max.tab[,3] <- (unlist(bal.max[2,-1]) - unlist(bal.max[1,-1]))/pooled.sd

um.wt.bias <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.sd
bl.wt.bias <- (unlist(bal.0[2,-1]) - unlist(bal.0[1,-1]))/pooled.sd  
bl.mx.bias <- (unlist(bal.max[2,-1]) - unlist(bal.max[1,-1]))/pooled.sd 

## Bias Reduction
(1 - (mean(abs(bl.wt.bias))/mean(abs(um.wt.bias))))*100
(1 - (mean(abs(bl.mx.bias))/mean(abs(um.wt.bias))))*100

rownames(um.wt.tab) <- all.cov
rownames(bal.max.tab) <- all.cov


round(cbind(um.wt.tab, bl.wt.bias), 3)
round(cbind(um.wt.tab, bl.mx.bias), 3)

lg.un <-  um.wt.tab[which(abs(um.wt.tab[,3]) > .1),]
lg.wt <- bal.0.tab[which(abs(um.wt.tab[,3]) > .1),]
lg.mx <- bal.max.tab[which(abs(um.wt.tab[,3]) > .1),]

### Plots and Tables
var_names <- c("Transfer Patient 0/1", "Medicaid", "No. Patients",
               "No. Patients Sqd.", "Level I Trauma Center", 
               "Proportion of General Surgery Cases",
               "% Emergency Cases", "% Medicaid Patients")	
n_covs <- length(var_names)

data.plot <- c(lg.wt[,3], lg.mx[,3], lg.un[,3])
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "std.dif"
data.plot$contrast <- c(rep(1, n_covs), rep(2, n_covs), rep(3, n_covs))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2, 3), labels = c("ATT Weights", "ATO Weights", "Unweighted"))
data.plot$covariate <- as.factor(var_names)

## Figure 1
pdf("magnet-std-diff-plot-1.pdf", width=8, height=8, onefile=FALSE, paper="special")	
ggplot(data=data.plot, aes(x=std.dif, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,2,3)) + 
          xlab("Standardized Difference") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          geom_vline(xintercept= 0) +
          geom_vline(xintercept= 0.1, linetype = "dashed") +
          geom_vline(xintercept= -0.1, linetype = "dashed") +
          theme_bw() +
          theme(axis.text.y=element_text(size=12))
dev.off()
