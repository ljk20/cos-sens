
library(foreign)
library(balancer)
library(lme4)
library(sjstats)
library(ICC)
library(tidyverse)
library(CVXR)



#RUN SENSITIVITY:

# ATT Estimand

setwd("~/Dropbox/Group Matches/Analysis/Magnet/routput")
load("att-sens-out.RData")

## Adverse
att_bounds_msm_a
row <- which(att_bounds_msm_a[, 1] * att_bounds_msm_a[, 2] < 0)[1] - 1
r11 <- rownames(att_bounds_msm_a)[row]
r11

## Adverse Events
att_bounds_vbm_a
row <- which(att_bounds_vbm_a[, 1] * att_bounds_vbm_a[, 2] < 0)[1] - 1
r12 <- rownames(att_bounds_vbm_a)[row]
r12

## FTR
att_bounds_msm_f
row <- which(att_bounds_msm_f[, 1] * att_bounds_msm_f[, 2] < 0)[1] - 1
r13 <- rownames(att_bounds_msm_f)[row]
r13

## Adverse Events
att_bounds_vbm_f
row <- which(att_bounds_vbm_f[, 1] * att_bounds_vbm_f[, 2] < 0)[1] - 1
r14 <- rownames(att_bounds_vbm_f)[row]
r14

row1 <- c(r11, r12, r13, r14)
  

#-------------------------------------------------
# ATO Estimand

load("ato-sens-out.RData")
     
ato_bounds_msm_a
row <- which(ato_bounds_msm_a[, 1] * ato_bounds_msm_a[, 2] < 0)[1] 
r21 <- rownames(ato_bounds_msm_a)[row]
r21

## Adverse Events
ato_bounds_vbm_a
row <- which(ato_bounds_vbm_a[, 1] * ato_bounds_vbm_a[, 2] < 0)[1]
r22 <- rownames(ato_bounds_vbm_a)[row]
r22

## FTR
ato_bounds_msm_f
row <- which(ato_bounds_msm_f[, 1] * ato_bounds_msm_f[, 2] < 0)[1] - 1
r23 <- rownames(ato_bounds_msm_f)[row]
r23

## Adverse Events
ato_bounds_vbm_f
row <- which(ato_bounds_vbm_f[, 1] * ato_bounds_vbm_f[, 2] < 0)[1] 
r24 <- rownames(ato_bounds_vbm_f)[row]
r24

row2 <- c(r21, r22, r23, r24)

library(xtable)

tab <- rbind(row1, row2)

xtable(tab)                       