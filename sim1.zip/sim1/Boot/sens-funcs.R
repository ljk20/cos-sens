
generate_data<-function(N=10000, beta=c(1, 1), gamma=c(1,1), rho=0){
  #Unload coefficients:
  gamma1 = gamma[1]
  gamma2 = gamma[2]
  beta1 = beta[1]
  beta2 = beta[2]
  #Selection scores:
  X = MASS::mvrnorm(n = N, mu=c(0,0),
                    Sigma = matrix(c(1, rho,
                                     rho, 1), byrow=TRUE, nrow=2),
                    tol = 1e-06, empirical = FALSE)
  X1 = X[,1]
  X2 = X[,2]
  
  treatment_prob =  plogis(gamma1*X1 + gamma2*X2)# - gamma3*X1*X2)
  Z = rbinom(N, size = 1, prob = treatment_prob)
  #Control Potential Outcomes
  Y0 = beta1*X1 + beta2*X2 + rnorm(N, 0, 1) # + beta3*X1*X2
  
  tau = 2
  
  #Treatment Potential Outcomes
  Y1 = Y0 + tau + rnorm(N, 0, 1)
  
  return(data.frame(Y = ifelse(Z==1, Y1, Y0),
                    Y0, Y1, X1, X2, treatment_prob, Z))
}


generate_data2 <- function(N=10000, beta=c(1, 1), gamma=c(1,1), rho=0){
  #Unload coefficients:
  gamma1 = gamma[1]
  gamma2 = gamma[2]
  beta1 = beta[1]
  beta2 = beta[2]
  #Selection scores:
  X = MASS::mvrnorm(n = N, mu=c(0,0),
                    Sigma = matrix(c(1, rho,
                                     rho, 1), byrow=TRUE, nrow=2),
                    tol = 1e-06, empirical = FALSE)
  X1 = X[,1]
  X2 = X[,2]
  
  treatment_prob =  plogis(gamma1*X1 + gamma2*X2)# - gamma3*X1*X2)
  Z = rbinom(N, size = 1, prob = treatment_prob)
  #Control Potential Outcomes
  #Y0 = beta1*X1 + beta2*X2 + rnorm(N, 0, 1) # + beta3*X1*X2
  
  tau = 2
  
  mu.y0 <- beta1*X1 + beta2*X2 + rnorm(N, 0, 1)
  mu.y1 <- mu.y0 + tau
  
  Y0 <- rbinom(N, 1, plogis(mu.y0))
  Y1 <- rbinom(N, 1, plogis(mu.y1))
  Y <- Z*Y1 + (1 - Z)*Y0
  
  return(data.frame(Y = Y,
                    Y0, Y1, X1, X2, treatment_prob, Z))
}


estimate_zbs_bounds<-function(weights, Y, lambda){
  #Optimization procedure
  weights = weights[order(-Y)]
  Y = Y[order(-Y)]
  num_high = (weights*lambda)*Y
  num_low = (weights/lambda)*Y
  den_high = weights*lambda
  den_low = weights/lambda
  
  den = c(0, cumsum(den_high)) + c(rev(cumsum(rev(den_low))), 0)
  num = c(0, cumsum(num_high)) + c(rev(cumsum(rev(num_low))), 0)
  Y_max = max(num/den)
  Y_max_unnorm = max(num)/length(weights)
  cutoff_max = which.max(num/den)
  cutoff_max_unnorm = which.max(num)
  
  den = c(0, cumsum(den_low)) + c(rev(cumsum(rev(den_high))), 0)
  num = c(0, cumsum(num_low)) + c(rev(cumsum(rev(num_high))), 0)
  Y_min = min(num/den)
  
  return(data.frame(min = Y_min, max = Y_max))
}

estimate_vbm_bounds<-function(R2, weights, Z, Y, type = "ATT"){
  mu1 = mean(Y[Z==1]*weights[Z==1])/mean(weights[Z==1])
  mu0 = mean(Y[Z==0]*weights[Z==0])/mean(weights[Z==0])
  cor1_bound = sqrt(1-cor(weights[Z==1], Y[Z==1])^2)
  cor0_bound = sqrt(1-cor(weights[Z==0], Y[Z==0])^2)
  if(type == "ATO"){
    Y1_bias = cor1_bound*sqrt(var(weights[Z==1])*(R2/(1-R2))*var(Y[Z==1]))
    Y0_bias = cor0_bound*sqrt(var(weights[Z==0])*(R2/(1-R2))*var(Y[Z==0]))  
  }else if(type == "ATT"){
    Y1_bias = 0
    Y0_bias = cor0_bound*sqrt(var(weights[Z==0])*(R2/(1-R2))*var(Y[Z==0]))  
  }
  
  return(data.frame(min = (mu1-Y1_bias) - (mu0+Y0_bias), max = (mu1+Y1_bias) - (mu0-Y0_bias)))
}



estimate_msm_bounds<-function(lambda, weights, Z, Y, type = "ATT"){
  if(length(lambda) > 1){
    mu1_bounds = lapply(lambda, estimate_zbs_bounds, weights = weights[Z==1], Y = Y[Z==1]) |> dplyr::bind_rows()
    mu0_bounds = lapply(lambda, estimate_zbs_bounds, weights = weights[Z==0], Y = Y[Z==0]) |> dplyr::bind_rows()
  }else{
    mu1_bounds = estimate_zbs_bounds(weights[Z==1], Y[Z==1], lambda)
    mu0_bounds = estimate_zbs_bounds(weights[Z==0], Y[Z==0], lambda)  
  }
  
  
  if(type == "ATO"){
    maxValue = mu1_bounds$max - mu0_bounds$min
    minValue = mu1_bounds$min - mu0_bounds$max  
  }else if(type == "ATT"){
    mu1 = mean(Y[Z==1]*weights[Z==1])/mean(weights[Z==1])
    maxValue = mu1 - mu0_bounds$min
    minValue = mu1 - mu0_bounds$max
  }
  
  return(data.frame(min = minValue, max = maxValue))
}
#-----------------------------------------------------------------------------
#df_sample<-generate_data(N=10000)

df_sample<-generate_data2(N=10000)
head(df_sample)

#Assume we omit X2
model_ps = WeightIt::weightit(Z~X1+X2, data = df_sample, method='ps', estimand="ATO")
weights = model_ps$weights
weights[df_sample$Z==1] = weights[df_sample$Z==1]/mean(weights[df_sample$Z==1])
weights[df_sample$Z==0] = weights[df_sample$Z==0]/mean(weights[df_sample$Z==0])

summary(estimatr::lm_robust(Y~Z, weights = weights, data = df_sample))

model_ps_oracle = WeightIt::weightit(Z~X1+X2, data = df_sample, method='ps', estimand="ATO")
weights_oracle = model_ps_oracle$weights


estimate_vbm_bounds(seq(0, 0.5, by = 0.1), weights, df_sample$Z,  df_sample$Y, type = "ATO")
estimate_msm_bounds(seq(1, 1.5, by =0.1), weights, df_sample$Z,  df_sample$Y, type = "ATO")


## ATT
model_ps = WeightIt::weightit(Z~X1+X2, data = df_sample, method='ps', estimand="ATT")
weights = model_ps$weights
weights[df_sample$Z==1] = weights[df_sample$Z==1]/mean(weights[df_sample$Z==1])
weights[df_sample$Z==0] = weights[df_sample$Z==0]/mean(weights[df_sample$Z==0])

summary(estimatr::lm_robust(Y~Z, weights = weights, data = df_sample))

estimate_vbm_bounds(seq(0, 0.5, by = 0.1), weights, df_sample$Z,  df_sample$Y, type = "ATT")
estimate_msm_bounds(seq(1, 1.5, by = 0.1), weights, df_sample$Z,  df_sample$Y, type = "ATT")


