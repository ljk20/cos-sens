
library(foreign)
library(MASS)
library(dplyr)
library(balancer)
library(clubSandwich)
library(lme4)
library(sjstats)

rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Simulation")
data <- read.dta("myon_merge.dta")

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens")
source("sens-funcs.R")
load("Sens-Parameters.RData")

#Covariate Lists
bal.cov <- c('readprof','mathprof','readpre','mathpre',
             'hisp','afam','male',
			 'perfcomp','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite')
                       
all.cov <- c('readpre','mathpre','hisp','afam','male','spec_ed', 
			 'perfcomp','readprof','mathprof','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite','title1','title1_focus',
              'treat', 'readpost_imp', 'schoolid')             
             
school.cov <- c('perfcomp','readprof','mathprof','pr_frl','pr_lep',
                'n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite')

student.cov <- c('readpre','mathpre','hisp','afam','male')


school.cov.ms <- c('pr_frl','pr_lep',
                   'n_students','pr_t_begin','pr_turnover',
                   'pr_t_nonwhite')

student.cov.ms <- c('hisp','afam','male')


# Resample with Replacement Bootstrap Function
clus.boot.data <- function(data, cluster){
    clusters <- names(table(cluster))
    index <- sample(1:length(clusters), length(clusters), replace=TRUE)
    aa <- clusters[index]
    bb <- table(aa)
    bootdat <- NULL
    
    for(j in 1:max(bb)){
      cc <- data[cluster %in% names(bb[bb %in% j]),]
      
      for(k in 1:j){
        bootdat <- rbind(bootdat, cc)
      }
    }
    return(bootdat)
    } 
                                             
# Trim the Data             
data.split <- data[all.cov]

# Remove Schools With One Student
data.split <- data.split %>% filter( !schoolid %in% c(398, 452,  474, 571, 620))

# Sim parameters
nsim <- 500
c <- 10
z.thresh <- .25

n <- nrow(data.split)
schl.ids <- unique(data.split$schoolid)
n.cl <- length(unique(data.split$schoolid))
nPerClust = tapply(data.split$treat, data.split$schoolid, length)
nCum  = c(0, cumsum(nPerClust))

sd.Y.ctl <- data.split %>% filter(treat==0) %>% dplyr::select(readpost_imp)  %>% summarize(sd(readpost_imp))
sd.Y.ctl <- sd.Y.ctl[[1]]

pscore <-lm(treat ~    readprof + mathprof + perfcomp + pr_frl + pr_lep +
                       n_students + pr_t_begin + pr_t_nonwhite, 
                       data=data.split)  
data.split$prob <- predict(pscore)
school.data <- data.split %>% group_by(schoolid) %>% summarize(z = mean(prob)) %>% data_frame()
      
# Estimate Covariate Outcome Relationships
out <- lm(readpost_imp ~ readpre + mathpre + hisp + afam + male + readpre:afam + mathpre:afam, data=data.split)
# Basis Function  
X <- as.matrix(data.split[bal.cov])
treat.true <- sd(data.split$readpost_imp)*.3                                                   
 
# Sim Storage
out.unadj <- matrix(NA, nsim, 3)
out.wgt.1 <- matrix(NA, nsim, 3)
out.wgt.2 <- matrix(NA, nsim, 3)
out.wgt.3 <- matrix(NA, nsim, 3)
out.wgt.4 <- matrix(NA, nsim, 3)


out.wgt.star.1 <- matrix(NA, nsim, 3)
out.wgt.star.2 <- matrix(NA, nsim, 3)
out.wgt.star.3 <- matrix(NA, nsim, 3)
out.wgt.star.4 <- matrix(NA, nsim, 3)

set.seed(12387474)

# Simulations
for(i in 1:nsim){
  	
# Generate Data 
    z.star <- (school.data$z/c) + runif(n.cl, -.5, .5)
    Z.j <- as.numeric(z.star > z.thresh) 	
    y0 <- out$coef[1] + 2.5*data.split$readpre + 2.5*data.split$mathpre + 1.9*data.split$perfcomp + rnorm(n, 0, 12)
    y1 <- y0 + treat.true 
    
      
# Student Level Data
     data.sim = matrix(0, n, (4+ncol(X)))
	 colnames(data.sim) = c("J", "I", "Z", "Y", bal.cov)
	 cl <- 1	
	  
for(cl in 1:n.cl){
	index.cl = (nCum[cl]+1):nCum[cl + 1] 
	
	## data for cluster "cl"	
	data.sim[index.cl, 1] = cl
	data.sim[index.cl, 2] = 1:nPerClust[cl]
	data.sim[index.cl, 3] = rep(Z.j[cl], nPerClust[cl])
	data.sim[index.cl, 4] = (rep(Z.j[cl], nPerClust[cl]))*(y1[index.cl]) + (1 - (rep(Z.j[cl], nPerClust[cl])))*y0[index.cl]                                        
	data.sim[index.cl, 5:(4+ncol(X))] = X[index.cl,]
	data.sim <- as.data.frame(data.sim)
    }
  
### Weighting MS 1

## Hyperparameter Selection
   all_covs_form <- paste(paste(student.cov.ms, collapse = "+"), "+", paste(school.cov, collapse = "+"))
   fit <- lmer(as.formula(paste("Y ~ ", all_covs_form, "+(1 | J)")), data.sim)
   fit_icc <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$J[1,-1]^2))
   fit_lambda <- fit_var / fit_beta_norm^2

   stu_covs <- scale(data.sim[, student.cov.ms])
   sch_covs <- scale(data.sim[,school.cov])
   bal2 <- cluster_weights(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE)
                           
   data.sim$w <- pmax(bal2$weights, 0)
   data.sim$w[data.sim$Z == 1] <- 1
   data.sim$weights1 = data.sim$w
   data.sim$weights1[data.sim$Z==0] = data.sim$weights1[data.sim$Z==0]/mean(data.sim$weights1[data.sim$Z==0])
                        
  
bounds_vbm  = estimate_vbm_bounds(c(0, par.unit.var), data.sim$weights1, data.sim$Z, data.sim$Y, type = "ATT")
bounds_msm = estimate_msm_bounds(c(1, par.unit.marg), data.sim$weights1, data.sim$Z, data.sim$Y, type = "ATT")
 

## Weighting MS 2
   all_covs_form <- paste(paste(student.cov, collapse = "+"), "+", paste(school.cov.ms, collapse = "+"))
   fit <- lmer(as.formula(paste("Y ~ ", all_covs_form, "+(1 | J)")), data.sim)
   fit_icc <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$J[1,-1]^2))
   fit_lambda2 <- fit_var / fit_beta_norm^2

   stu_covs <- scale(data.sim[, student.cov])
   sch_covs <- scale(data.sim[,school.cov.ms])
   bal3 <- cluster_weights(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda2, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE)
  
   data.sim$w2 <- pmax(bal3$weights, 0)
   data.sim$w2[data.sim$Z == 1] <- 1
   data.sim$weights2 = data.sim$w2
   data.sim$weights2[data.sim$Z==0] = data.sim$weights2[data.sim$Z==0]/mean(data.sim$weights2[data.sim$Z==0])
   
bounds_vbm2  = estimate_vbm_bounds(c(0, par.clus.var), data.sim$weights2, data.sim$Z, data.sim$Y, type = "ATT")
bounds_msm2 = estimate_msm_bounds(c(1, par.clus.marg), data.sim$weights2, data.sim$Z, data.sim$Y, type = "ATT") 

# Save Results
    out.wgt.1[i,1] <- bounds_vbm[1,2]    
    out.wgt.1[i,2] <- bounds_vbm[2,1]
    out.wgt.1[i,3] <- bounds_vbm[2,2]
    
    out.wgt.2[i,1] <- bounds_msm[1,2]
    out.wgt.2[i,2] <- bounds_msm[2,1]
    out.wgt.2[i,3] <- bounds_msm[2,2]
    
    out.wgt.3[i,1] <- bounds_vbm2[1,2]
    out.wgt.3[i,2] <- bounds_vbm2[2,1]
    out.wgt.3[i,3] <- bounds_vbm2[2,2]
    
    out.wgt.4[i,1] <- bounds_msm2[1,2]
    out.wgt.4[i,2] <- bounds_msm2[2,1]
    out.wgt.4[i,3] <- bounds_msm2[2,2]  
    
    
## Bootstrap Step
nboots <- 1000
out.boot.1 <- matrix(NA, nboots, 3)
out.boot.2 <- matrix(NA, nboots, 3)
out.boot.3 <- matrix(NA, nboots, 3)
out.boot.4 <- matrix(NA, nboots, 3)

cat( "Simulation: ", i, "\n" )

  for(j in 1:nboots){
  	

     boot.dat <- clus.boot.data(data.sim, data.sim$J)
     foo <- sum(boot.dat$Z)
     foo2 <- sum(1 - boot.dat$Z)
     if(foo < 100 | foo2 < 100){
     boot.dat <- clus.boot.data(data.sim, data.sim$J)		
     }
    
        stu_covs_st1 <- scale(boot.dat[, student.cov.ms])
        sch_covs_st1 <- scale(boot.dat[,school.cov])
        
       bal1_st <- try(cluster_weights(stu_covs_st1, sch_covs_st1, boot.dat$Z, boot.dat$J,
                  lambda = fit_lambda, icc = fit_icc,
                  lowlim = 0, uplim = 1, verbose = FALSE),silent = TRUE)

if (inherits(bal1_st, "try-error")) {
    cat("Error in iteration", i, "- generate new data\n")
    cat("Treat Table:", table(boot.dat$Z), "\n")
    boot.dat <- clus.boot.data(data.sim, data.sim$J)
    stu_covs_st1 <- scale(boot.dat[, student.cov.ms])
    sch_covs_st1 <- scale(boot.dat[,school.cov])
    bal1_st <- cluster_weights(stu_covs_st1, sch_covs_st1, boot.dat$Z, boot.dat$J,
                  lambda = fit_lambda, icc = fit_icc,
                  lowlim = 0, uplim = 1, verbose = FALSE)
    boot.dat$w <- pmax(bal1_st$weights, 0)              
  } else {
    boot.dat$w <- pmax(bal1_st$weights, 0)
  }

       boot.dat$w[boot.dat$Z == 1] <- 1
       boot.dat$weights1 = boot.dat$w
       boot.dat$weights1[boot.dat$Z==0] = boot.dat$weights1[boot.dat$Z==0]/mean(boot.dat$weights1[boot.dat$Z==0])

     bounds_vbm_star  = estimate_vbm_bounds(c(0, par.unit.var), boot.dat$weights1, boot.dat$Z, boot.dat$Y, type = "ATT")
     bounds_msm_star = estimate_msm_bounds(c(1, par.unit.marg), boot.dat$weights1, boot.dat$Z, boot.dat$Y, type = "ATT")

      stu_covs_st2 <- scale(boot.dat[, student.cov])
      sch_covs_st2 <- scale(boot.dat[,school.cov.ms])
      
      bal3_st <- try(cluster_weights(stu_covs_st2, sch_covs_st2, boot.dat$Z, boot.dat$J,
                           lambda = fit_lambda2, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE), silent = TRUE)

if (inherits(bal3_st, "try-error")) {
    cat("Error in iteration", i, "- using default weights\n")
    cat("Treat Table:", table(boot.dat$Z), "\n")
    boot.dat <- clus.boot.data(data.sim, data.sim$J)
    stu_covs_st2 <- scale(boot.dat[, student.cov])
    sch_covs_st2 <- scale(boot.dat[,school.cov.ms])
    bal3_st <- cluster_weights(stu_covs_st2, sch_covs_st2, boot.dat$Z, boot.dat$J,
                       lambda = fit_lambda2, icc = fit_icc,
                       lowlim = 0, uplim = 1, verbose=FALSE)
    boot.dat$w2 <- pmax(bal3_st$weights, 0)                   
  } else {
    boot.dat$w2 <- pmax(bal3_st$weights, 0)
  }

       boot.dat$w2[boot.dat$Z == 1] <- 1
       boot.dat$weights2 = boot.dat$w2
       boot.dat$weights2[boot.dat$Z==0] = boot.dat$weights2[boot.dat$Z==0]/mean(boot.dat$weights2[boot.dat$Z==0])
              
bounds_vbm_star2  = estimate_vbm_bounds(c(0, par.clus.var), boot.dat$weights2, boot.dat$Z, boot.dat$Y, type = "ATT")
bounds_msm_star2 = estimate_msm_bounds(c(1, par.clus.marg), boot.dat$weights2, boot.dat$Z, boot.dat$Y, type = "ATT")
               
    out.boot.1[j,1] <- bounds_vbm_star[1,2]    
    out.boot.1[j,2] <- bounds_vbm_star[2,1]
    out.boot.1[j,3] <- bounds_vbm_star[2,2]
    
    out.boot.2[j,1] <- bounds_msm_star[1,2]
    out.boot.2[j,2] <- bounds_msm_star[2,1]
    out.boot.2[j,3] <- bounds_msm_star[2,2]
    
    out.boot.3[j,1] <- bounds_vbm_star2[1,2]
    out.boot.3[j,2] <- bounds_vbm_star2[2,1]
    out.boot.3[j,3] <- bounds_vbm_star2[2,2]
    
    out.boot.4[j,1] <- bounds_msm_star2[1,2]
    out.boot.4[j,2] <- bounds_msm_star2[2,1]
    out.boot.4[j,3] <- bounds_msm_star2[2,2]                                  
   }
   
   
# Save Boot Results
    out.wgt.star.1[i,1] <- mean(out.boot.1[,1], na.rm=TRUE)    
    out.wgt.star.1[i,2] <- mean(out.boot.1[,2], na.rm=TRUE)
    out.wgt.star.1[i,3] <- mean(out.boot.1[,3], na.rm=TRUE)
    
    out.wgt.star.2[i,1] <- mean(out.boot.2[,1], na.rm=TRUE)
    out.wgt.star.2[i,2] <- mean(out.boot.2[,2], na.rm=TRUE)
    out.wgt.star.2[i,3] <- mean(out.boot.2[,3], na.rm=TRUE)
    
    out.wgt.star.3[i,1] <- mean(out.boot.3[,1], na.rm=TRUE)
    out.wgt.star.3[i,2] <- mean(out.boot.3[,2], na.rm=TRUE)
    out.wgt.star.3[i,3] <- mean(out.boot.3[,3], na.rm=TRUE)
    
    out.wgt.star.4[i,1] <- mean(out.boot.4[,1], na.rm=TRUE)
    out.wgt.star.4[i,2] <- mean(out.boot.4[,2], na.rm=TRUE)
    out.wgt.star.4[i,3] <- mean(out.boot.4[,3], na.rm=TRUE) 

}


   
# simulation summaries   

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

# School Omitted
o3 <- apply(out.wgt.3, 2, mean, na.rm=TRUE)
o4 <- apply(out.wgt.4, 2, mean, na.rm=TRUE)

o1
o2
o3
o4

mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))
mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))


mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])))
mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])))
mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])))
mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])))


setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Boot")
save(out.wgt.1, out.wgt.2, out.wgt.3, out.wgt.4, 
     out.wgt.star.1, out.wgt.star.2, out.wgt.star.3, out.wgt.star.4,
     treat.true, file ="Sim-Sens-Boot-C10.RData")	
     
     
     
     
     