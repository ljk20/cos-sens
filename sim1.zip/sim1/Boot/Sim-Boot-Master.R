

rm(list=ls())

source("Sim-Sens-Boot-C1.R")
source("Sim-Sens-Boot-C5.R")
source("Sim-Sens-Boot-C10.R")

