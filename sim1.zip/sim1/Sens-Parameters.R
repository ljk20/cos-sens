
library(foreign)
library(MASS)
library(dplyr)
library(balancer)
library(clubSandwich)
library(lme4)
library(sjstats)

rm(list=ls())

data <- read.dta("myon_merge.dta")

#Covariate Lists
bal.cov <- c('readprof','mathprof','readpre','mathpre',
             'hisp','afam','male',
			 'perfcomp','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite')
             
all.cov <- c('readpre','mathpre','hisp','afam','male','spec_ed', 
			 'perfcomp','readprof','mathprof','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite','title1','title1_focus',
              'treat', 'readpost_imp', 'schoolid')             
             
school.cov <- c('perfcomp','readprof','mathprof','pr_frl','pr_lep',
                'n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite')

student.cov <- c('readpre','mathpre','hisp','afam','male')


school.cov.ms <- c('pr_frl','pr_lep',
                   'n_students','pr_t_begin','pr_turnover',
                   'pr_t_nonwhite')

student.cov.ms <- c('hisp','afam','male')

unit.ms <- c('perfcomp','readprof','mathprof','pr_frl','pr_lep',
                'n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite','hisp','afam','male')

cluster.ms <- c('pr_frl','pr_lep','n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite','readpre','mathpre','hisp','afam','male')
                                             
# Trim the Data             
data.split <- data[all.cov]

# Remove Schools With One Student
data.split <- data.split %>% filter( !schoolid %in% c(398, 452,  474, 571, 620))

# Sim parameters
nsim <- 1000
c <- 1
z.thresh <- .25

n <- nrow(data.split)
schl.ids <- unique(data.split$schoolid)
n.cl <- length(unique(data.split$schoolid))
nPerClust = tapply(data.split$treat, data.split$schoolid, length)
nCum  = c(0, cumsum(nPerClust))

sd.Y.ctl <- data.split %>% filter(treat==0) %>% dplyr::select(readpost_imp)  %>% summarize(sd(readpost_imp))
sd.Y.ctl <- sd.Y.ctl[[1]]

pscore <-lm(treat ~ readprof + mathprof + perfcomp + pr_frl + pr_lep +
                       n_students + pr_t_begin + pr_t_nonwhite, 
                       data=data.split)  
data.split$prob <- predict(pscore)


school.data <- data.split %>% group_by(schoolid) %>% summarize(z = mean(prob)) %>% data_frame()
    
# Estimate Covariate Outcome Relationships
out <- lm(readpost_imp ~ readpre + mathpre + hisp + afam + male + readpre:afam + mathpre:afam, data=data.split)
X <- as.matrix(data.split[bal.cov])
treat.true <- sd(data.split$readpost_imp)*.3  
                                                 
set.seed(12387474)

out.var.unit <- matrix(NA, nsim, 1)
out.marg.unit <- matrix(NA, nsim, 1)
out.var.clus <- matrix(NA, nsim, 1)
out.marg.clus <- matrix(NA, nsim, 1)

# Simulations
  for(i in 1:nsim){ 
  	  	
# Generate Data 
    z.star <- (school.data$z) + runif(n.cl, -.5, .5)
    Z.j <- as.numeric(z.star > z.thresh) 	
    y0 <- out$coef[1] + 2.5*data.split$readpre + 2.5*data.split$mathpre + 1.9*data.split$perfcomp + rnorm(n, 0, 12)
    y1 <- y0 + treat.true 
    
      
# Student Level Data
     data.sim = matrix(0, n, (4+ncol(X)))
	 colnames(data.sim) = c("J", "I", "Z", "Y", bal.cov)
	 cl <- 1	
	  
for(cl in 1:n.cl){
	index.cl = (nCum[cl]+1):nCum[cl + 1] 
	
	## data for cluster "cl"	
	data.sim[index.cl, 1] = cl
	data.sim[index.cl, 2] = 1:nPerClust[cl]
	data.sim[index.cl, 3] = rep(Z.j[cl], nPerClust[cl])
	data.sim[index.cl, 4] = (rep(Z.j[cl], nPerClust[cl]))*(y1[index.cl]) + (1 - (rep(Z.j[cl], nPerClust[cl])))*y0[index.cl]                                        
	data.sim[index.cl, 5:(4+ncol(X))] = X[index.cl,]
	data.sim <- as.data.frame(data.sim)
    }
    
    
## Estimate Propensity Scores
## Process Weights
 psmod.oracle <- glm(reformulate(bal.cov, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$o.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.oracle$linear.predictors), 1)
 data.sim$o.wts[data.sim$Z==0] = data.sim$o.wts.p[data.sim$Z==0]/mean(data.sim$o.wts.p[data.sim$Z==0])
 
 psmod.unit.ms <- glm(reformulate(unit.ms, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$u.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.unit.ms$linear.predictors), 1)
 data.sim$u.wts[data.sim$Z==0] = data.sim$u.wts.p[data.sim$Z==0]/mean(data.sim$u.wts.p[data.sim$Z==0])
 summary(data.sim$u.wts)
 
 psmod.clus.ms <- glm(reformulate(cluster.ms, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$c.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.clus.ms$linear.predictors), 1) 
 data.sim$c.wts[data.sim$Z==0] = data.sim$c.wts.p[data.sim$Z==0]/mean(data.sim$c.wts.p[data.sim$Z==0])
 summary(data.sim$c.wts)
  
# Save Results
    out.var.unit[i] <- 1 - (var(data.sim$u.wts[data.sim$Z==0])/var(data.sim$o.wts[data.sim$Z==0]))
    out.marg.unit[i] <- max(max(data.sim$o.wts[data.sim$Z==0]/data.sim$u.wts[data.sim$Z==0]), max(data.sim$u.wts[data.sim$Z==0]/data.sim$o.wts[data.sim$Z==0]))
    out.var.clus[i] <- 1 - (var(data.sim$c.wts[data.sim$Z==0])/var(data.sim$o.wts[data.sim$Z==0]))
    out.marg.clus[i] <- max(max(data.sim$o.wts[data.sim$Z==0]/data.sim$c.wts[data.sim$Z==0]), max(data.sim$c.wts[data.sim$Z==0]/data.sim$o.wts[data.sim$Z==0]))

   cat("Simulation: ", i, "\n") 
   }
   
    par.unit.var <- mean(out.var.unit, na.rm=TRUE)
    par.unit.marg <- mean(out.marg.unit, na.rm=TRUE)
    par.clus.var <- mean(out.var.clus, na.rm=TRUE)
    par.clus.marg <- quantile(out.marg.clus, prob = .2, na.rm=TRUE)
    
    par.unit.var 
    par.unit.marg 
    par.clus.var 
    par.clus.marg 
    
save(par.unit.var, 
    par.unit.marg, 
    par.clus.var, 
    par.clus.marg, file ="Sens-Parameters.RData")	
