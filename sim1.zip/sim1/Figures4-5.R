## Move to Other Script


library(tidyverse)
library(gridExtra)

rm(list=ls())

load("Sim-Sens-C1.RData")

lng.u.vbm.c1 <- mean(abs((out.wgt.1[,2] - out.wgt.1[,3])))
lng.u.msm.c1 <- mean(abs((out.wgt.2[,2] - out.wgt.2[,3])))

lng.c.vbm.c1 <- mean(abs((out.wgt.3[,2] - out.wgt.3[,3])))
lng.c.msm.c1 <- mean(abs((out.wgt.4[,2] - out.wgt.4[,3])))


cvg.u.vbm.c1 <- mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
cvg.u.msm.c1 <- mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))

cvg.c.vbm.c1 <- mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
cvg.c.msm.c1 <- mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))

c1.leng <- c(lng.u.vbm.c1, lng.u.msm.c1, lng.c.vbm.c1, lng.c.msm.c1)
c1.cvg <- c(cvg.u.vbm.c1, cvg.u.msm.c1, cvg.c.vbm.c1, cvg.c.msm.c1)

rm(lng.u.vbm.c1, lng.u.msm.c1, lng.c.vbm.c1, lng.c.msm.c1,
   cvg.u.vbm.c1, cvg.u.msm.c1, cvg.c.vbm.c1, cvg.c.msm.c1)

load("./Boot/Sim-Sens-Boot-C1.RData")

e.cvg.u.vbm.c1 <- mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])), na.rm=TRUE)
e.cvg.u.msm.c1 <- mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])), na.rm=TRUE)
e.cvg.c.vbm.c1 <- mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])), na.rm=TRUE)
e.cvg.c.msm.c1 <- mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])), na.rm=TRUE)

c1.e.cvg <- c(e.cvg.u.vbm.c1, e.cvg.u.msm.c1, e.cvg.c.vbm.c1, e.cvg.c.msm.c1)

load("Sim-Sens-C5.RData")

lng.u.vbm.c5 <- mean(abs((out.wgt.1[,2] - out.wgt.1[,3])))
lng.u.msm.c5 <- mean(abs((out.wgt.2[,2] - out.wgt.2[,3])))

lng.c.vbm.c5 <- mean(abs((out.wgt.3[,2] - out.wgt.3[,3])))
lng.c.msm.c5 <- mean(abs((out.wgt.4[,2] - out.wgt.4[,3])))


cvg.u.vbm.c5 <- mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
cvg.u.msm.c5 <- mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))

cvg.c.vbm.c5 <- mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
cvg.c.msm.c5 <- mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))

c5.leng <- c(lng.u.vbm.c5, lng.u.msm.c5, lng.c.vbm.c5, lng.c.msm.c5)
c5.cvg <- c(cvg.u.vbm.c5, cvg.u.msm.c5, cvg.c.vbm.c5, cvg.c.msm.c5)

rm(lng.u.vbm.c5, lng.u.msm.c5, lng.c.vbm.c5, lng.c.msm.c5,
   cvg.u.vbm.c5, cvg.u.msm.c5, cvg.c.vbm.c5, cvg.c.msm.c5)

load("./Boot/Sim-Sens-Boot-C5.RData")

e.cvg.u.vbm.c5 <- mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])), na.rm=TRUE)
e.cvg.u.msm.c5 <- mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])), na.rm=TRUE)
e.cvg.c.vbm.c5 <- mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])), na.rm=TRUE)
e.cvg.c.msm.c5 <- mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])), na.rm=TRUE)

c5.e.cvg <- c(e.cvg.u.vbm.c5, e.cvg.u.msm.c5, e.cvg.c.vbm.c5, e.cvg.c.msm.c5)

load("Sim-Sens-C10.RData")

lng.u.vbm.c10 <- mean(abs((out.wgt.1[,2] - out.wgt.1[,3])))
lng.u.msm.c10 <- mean(abs((out.wgt.2[,2] - out.wgt.2[,3])))

lng.c.vbm.c10 <- mean(abs((out.wgt.3[,2] - out.wgt.3[,3])))
lng.c.msm.c10 <- mean(abs((out.wgt.4[,2] - out.wgt.4[,3])))

cvg.u.vbm.c10 <- mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
cvg.u.msm.c10 <- mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))

cvg.c.vbm.c10 <- mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
cvg.c.msm.c10 <- mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))

c10.leng <- c(lng.u.vbm.c10, lng.u.msm.c10, lng.c.vbm.c10, lng.c.msm.c10)
c10.cvg <- c(cvg.u.vbm.c10, cvg.u.msm.c10, cvg.c.vbm.c10, cvg.c.msm.c10)

rm(lng.u.vbm.c10, lng.u.msm.c10, lng.c.vbm.c10, lng.c.msm.c10,
   cvg.u.vbm.c10, cvg.u.msm.c10, cvg.c.vbm.c10, cvg.c.msm.c10)

load("./Boot/Sim-Sens-Boot-C10.RData")	

e.cvg.u.vbm.c10 <- mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])), na.rm=TRUE)
e.cvg.u.msm.c10 <- mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])), na.rm=TRUE)
e.cvg.c.vbm.c10 <- mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])), na.rm=TRUE)
e.cvg.c.msm.c10 <- mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])), na.rm=TRUE)

c10.e.cvg <- c(e.cvg.u.vbm.c10, e.cvg.u.msm.c10, e.cvg.c.vbm.c10, e.cvg.c.msm.c10)


sim.dat <- tibble(leng = c(c1.leng, c5.leng, c10.leng),
                 cvg = c(c1.cvg, c5.cvg, c10.cvg),
                 e.cvg = c(c1.e.cvg, c5.e.cvg, c10.e.cvg),
                 c.idx = c(rep(1, 4), rep(2,4), rep(3,4)),
                 method = rep(seq(1,4,1), 3))


sim.dat$method <- factor(sim.dat$method, levels =  c(1,2,3,4), labels = c("Unit Variance Model", "Unit Marginal Model", 
                                                                          "Cluster Variance Model","Cluster Marginal Model"))
sim.dat$c.idx <- factor(sim.dat$c.idx, levels =  c(1,2,3), labels = c("Poor Overlap", "Medium", "Good Overlap"))


unit.data <- sim.dat %>% filter(method == "Unit Variance Model" | method == "Unit Marginal Model")

p1 <- ggplot(unit.data, aes(x=c.idx, y=leng, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Bounds Length" ) +
  theme_bw() +
  theme(legend.position="none")  
  
p2 <- ggplot(unit.data, aes(x=c.idx, y=cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Proportion of Bounds That Include True Value" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.position="none")

p3 <- ggplot(unit.data, aes(x=c.idx, y=e.cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Nominal Coverage" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.title=element_blank())
   
pdf("sens-sim-unit.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(p1, p2, p3, nrow=1, widths = c(1,1,1.6))
dev.off() 


clus.data <- sim.dat %>% filter(method == "Cluster Variance Model" | method == "Cluster Marginal Model")
p3 <- ggplot(clus.data, aes(x=c.idx, y=leng, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Bounds Length" ) +
  theme_bw() +
  theme(legend.position="none")  
  
p4 <- ggplot(clus.data, aes(x=c.idx, y=cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Proportion of Bounds That Include True Value" ) +
  ylim(c(.9, 1)) +
  theme_bw() +
  theme(legend.position="none")

p5 <- ggplot(clus.data, aes(x=c.idx, y=e.cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  ylab( "Nominal Coverage" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.title=element_blank())
      
pdf("sens-sim-clus.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(p3, p4, p5, nrow=1, widths = c(1, 1, 1.6))
dev.off() 





  


