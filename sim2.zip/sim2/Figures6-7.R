
library(tidyverse)
library(gridExtra)

rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP")
load("Sim-Sens-ATT.RData")


lng.u.vbm.c1 <- mean(abs((out.wgt.1[,2] - out.wgt.1[,3])))
lng.u.msm.c1 <- mean(abs((out.wgt.2[,2] - out.wgt.2[,3])))

lng.c.vbm.c1 <- mean(abs((out.wgt.3[,2] - out.wgt.3[,3])))
lng.c.msm.c1 <- mean(abs((out.wgt.4[,2] - out.wgt.4[,3])))


cvg.u.vbm.c1 <- mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
cvg.u.msm.c1 <- mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))

cvg.c.vbm.c1 <- mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
cvg.c.msm.c1 <- mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))

c1.leng <- c(lng.u.vbm.c1, lng.u.msm.c1, lng.c.vbm.c1, lng.c.msm.c1)
c1.cvg <- c(cvg.u.vbm.c1, cvg.u.msm.c1, cvg.c.vbm.c1, cvg.c.msm.c1)

rm(lng.u.vbm.c1, lng.u.msm.c1, lng.c.vbm.c1, lng.c.msm.c1,
   cvg.u.vbm.c1, cvg.u.msm.c1, cvg.c.vbm.c1, cvg.c.msm.c1)

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP/Boot")
load("Sim-Sens-Boot-ATT.RData")	

e.cvg.u.vbm <- mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])))
e.cvg.u.msm <- mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])))

e.cvg.c.vbm <- mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])))
e.cvg.c.msm <- mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])))

e.cvg.att <- c(e.cvg.u.vbm, e.cvg.u.msm, e.cvg.c.vbm, e.cvg.c.msm)

rm(e.cvg.u.vbm, e.cvg.u.msm, e.cvg.c.vbm, e.cvg.c.msm)

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP") 
load("Sim-Sens-ATO.RData")

lng.u.vbm.c5 <- mean(abs((out.wgt.1[,2] - out.wgt.1[,3])))
lng.u.msm.c5 <- mean(abs((out.wgt.2[,2] - out.wgt.2[,3])))

lng.c.vbm.c5 <- mean(abs((out.wgt.3[,2] - out.wgt.3[,3])))
lng.c.msm.c5 <- mean(abs((out.wgt.4[,2] - out.wgt.4[,3])))


cvg.u.vbm.c5 <- mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
cvg.u.msm.c5 <- mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))

cvg.c.vbm.c5 <- mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
cvg.c.msm.c5 <- mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))

c5.leng <- c(lng.u.vbm.c5, lng.u.msm.c5, lng.c.vbm.c5, lng.c.msm.c5)
c5.cvg <- c(cvg.u.vbm.c5, cvg.u.msm.c5, cvg.c.vbm.c5, cvg.c.msm.c5)

rm(lng.u.vbm.c5, lng.u.msm.c5, lng.c.vbm.c5, lng.c.msm.c5,
   cvg.u.vbm.c5, cvg.u.msm.c5, cvg.c.vbm.c5, cvg.c.msm.c5)

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP/Boot")
load("Sim-Sens-Boot-ATO.RData")	

e.cvg.u.vbm <- mean(as.numeric((out.wgt.star.1[,2] < treat.true) & (treat.true < out.wgt.star.1[,3])))
e.cvg.u.msm <- mean(as.numeric((out.wgt.star.2[,2] < treat.true) & (treat.true < out.wgt.star.2[,3])))

e.cvg.c.vbm <- mean(as.numeric((out.wgt.star.3[,2] < treat.true) & (treat.true < out.wgt.star.3[,3])))
e.cvg.c.msm <- mean(as.numeric((out.wgt.star.4[,2] < treat.true) & (treat.true < out.wgt.star.4[,3])))

e.cvg.ato <- c(e.cvg.u.vbm, e.cvg.u.msm, e.cvg.c.vbm, e.cvg.c.msm)

sim.dat <- tibble(leng = c(c1.leng, c5.leng),
                 cvg = c(c1.cvg, c5.cvg),
                 e.cvg = c(e.cvg.att, e.cvg.ato),
                 c.idx = c(rep(1, 4), rep(2,4)),
                 method = rep(seq(1,4,1), 2))


sim.dat$method <- factor(sim.dat$method, levels =  c(1,2,3,4), labels = c("Unit Variance Model", "Unit Marginal Model", 
                                                                          "Cluster Variance Model","Cluster Marginal Model"))
sim.dat$c.idx <- factor(sim.dat$c.idx, levels =  c(1,2), labels = c("ATT", "ATO"))


unit.data <- sim.dat %>% filter(method == "Unit Variance Model" | method == "Unit Marginal Model")

p1 <- ggplot(unit.data, aes(x=c.idx, y=leng, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Bounds Length" ) +
  theme_bw() +
  theme(legend.position="none")  
  

p2 <- ggplot(unit.data, aes(x=c.idx, y=cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Proportion of Bounds That Include True Value" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.position="none")
  
p3 <- ggplot(unit.data, aes(x=c.idx, y=e.cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Nominal Coverage" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.title=element_blank())
   
grid.arrange(p1, p2, p3, nrow=1, widths = c(1,1,1.3))

setwd("~/Dropbox/Group Matches/Drafts/Sens/figures")
pdf("sens-sim-unit-alt-dgp.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(p1, p2, p3, nrow=1, widths = c(1,1,1.6))
dev.off() 


clus.data <- sim.dat %>% filter(method == "Cluster Variance Model" | method == "Cluster Marginal Model")

p3 <- ggplot(clus.data, aes(x=c.idx, y=leng, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Bounds Length" ) +
  theme_bw() +
  theme(legend.position="none")  
  
p4 <- ggplot(clus.data, aes(x=c.idx, y=cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Proportion of Bounds That Include True Value" ) +
  ylim(c(.9, 1)) +
  theme_bw() +
  theme(legend.position="none")
  
p5 <- ggplot(clus.data, aes(x=c.idx, y=e.cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Estimand") + 
  ylab( "Nominal Coverage" ) +
  ylim(c(.70, 1)) +
  theme_bw() +
  theme(legend.title=element_blank())
    
grid.arrange(p3, p4, p5, nrow=1, widths = c(1,1,1.6))

setwd("~/Dropbox/Group Matches/Drafts/Sens/figures")
pdf("sens-sim-clus-alt-dgp.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(p3, p4, p5, nrow=1, widths = c(1,1,1.6))
dev.off() 





  


