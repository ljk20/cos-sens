
library(foreign)
library(MASS)
library(dplyr)
library(balancer)
library(clubSandwich)
library(lme4)
library(sjstats)

rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP/Boot")
source("functions.R")
source("sens-funcs.R")
load("Sens-Parameters.RData")

#Covariate Lists
bal.cov <- c("cluster.x1", "cluster.x2", "h1", "h2",
             "h3", "h4", "x1", "x2", "x3", "x4", "x5")
             
             
cluster.cov <- c("cluster.x1", "cluster.x2", "h1", "h2", "h3", "h4")
unit.cov <- c("x1", "x2", "x3", "x4", "x5")

unit.ms <- c("x1", "x2", "x3", "x4")
cluster.ms <- c("cluster.x1", "cluster.x2", "h2", "h3", "h4")

nsim <- 1000

treat.true <- 0.16


# Resample with Replacement Bootstrap Function
clus.boot.data <- function(data, cluster){
    clusters <- names(table(cluster))
    index <- sample(1:length(clusters), length(clusters), replace=TRUE)
    aa <- clusters[index]
    bb <- table(aa)
    bootdat <- NULL
    
    for(j in 1:max(bb)){
      cc <- data[cluster %in% names(bb[bb %in% j]),]
      
      for(k in 1:j){
        bootdat <- rbind(bootdat, cc)
      }
    }
    return(bootdat)
    } 
                                                                                               
 
# Sim Storage
out.unadj <- matrix(NA, nsim, 3)
out.wgt.1 <- matrix(NA, nsim, 3)
out.wgt.2 <- matrix(NA, nsim, 3)
out.wgt.3 <- matrix(NA, nsim, 3)
out.wgt.4 <- matrix(NA, nsim, 3)


out.wgt.star.1 <- matrix(NA, nsim, 3)
out.wgt.star.2 <- matrix(NA, nsim, 3)
out.wgt.star.3 <- matrix(NA, nsim, 3)
out.wgt.star.4 <- matrix(NA, nsim, 3)

set.seed(12387474)

data.sim <- data_gen("tt3", I = 150, N = 5000)  
   all_covs_form <- paste(paste(unit.ms, collapse = "+"), "+", paste(cluster.cov, collapse = "+"))
   fit <- lmer(as.formula(paste("Y ~ ", all_covs_form, "+(1 | J)")), data.sim)
   fit_icc <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$J[1,-1]^2))
   fit_lambda <- fit_var / fit_beta_norm^2

 all_covs_form <- paste(paste(unit.cov, collapse = "+"), "+", paste(cluster.ms, collapse = "+"))
   fit <- lmer(as.formula(paste("Y ~ ", all_covs_form, "+(1 | J)")), data.sim)
   fit_icc2 <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$J[1,-1]^2))
   fit_lambda2 <- fit_var / fit_beta_norm^2

# Simulations
for(i in 1:nsim){
  	
data.sim <- data_gen("tt3", I = 150, N = 5000) 
  
### Weighting MS 1

  stu_covs <- scale(data.sim[, unit.ms])
   sch_covs <- scale(data.sim[,cluster.cov])
   bal2 <- maxsubset_weights_cluster(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose = FALSE)                         
   
   data.sim$w <- bal2$weights                       
   data.sim$w[data.sim$w < 0] <- 0
                         
  
   bounds_vbm  = estimate_vbm_bounds(c(0, par.unit.var), data.sim$w, data.sim$Z, data.sim$Y, type = "ATO")

   bounds_msm = estimate_msm_bounds(c(1, par.unit.marg), data.sim$w, data.sim$Z, data.sim$Y, type = "ATO")
 
## Weighting MS 2

   stu_covs <- scale(data.sim[, unit.cov])
   sch_covs <- scale(data.sim[,cluster.ms])
   bal3 <- maxsubset_weights_cluster(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc2,
                           lowlim = 0, uplim = 1, verbose = FALSE)    
  
   data.sim$w2 <- bal3$weights                       
   data.sim$w2[data.sim$w2 < 0] <- 0
                 
   bounds_vbm2  = estimate_vbm_bounds(c(0, par.clus.var), data.sim$w, data.sim$Z, data.sim$Y, type = "ATO")

   bounds_msm2 = estimate_msm_bounds(c(1, par.clus.marg), data.sim$w, data.sim$Z, data.sim$Y, type = "ATO")
   
# Save Results
    out.wgt.1[i,1] <- bounds_vbm[1,2]    
    out.wgt.1[i,2] <- bounds_vbm[2,1]
    out.wgt.1[i,3] <- bounds_vbm[2,2]
    
    out.wgt.2[i,1] <- bounds_msm[1,2]
    out.wgt.2[i,2] <- bounds_msm[2,1]
    out.wgt.2[i,3] <- bounds_msm[2,2]
    
    out.wgt.3[i,1] <- bounds_vbm2[1,2]
    out.wgt.3[i,2] <- bounds_vbm2[2,1]
    out.wgt.3[i,3] <- bounds_vbm2[2,2]
    
    out.wgt.4[i,1] <- bounds_msm2[1,2]
    out.wgt.4[i,2] <- bounds_msm2[2,1]
    out.wgt.4[i,3] <- bounds_msm2[2,2]   
    
    
## Bootstrap Step
nboots <- 1000
out.boot.1 <- matrix(NA, nboots, 3)
out.boot.2 <- matrix(NA, nboots, 3)
out.boot.3 <- matrix(NA, nboots, 3)
out.boot.4 <- matrix(NA, nboots, 3)

cat( "Simulation: ", i, "\n" )

  for(j in 1:nboots){
  	

     boot.dat <- clus.boot.data(data.sim, data.sim$J)
     foo <- sum(boot.dat$Z)
     if(foo < 100){
     boot.dat <- clus.boot.data(data.sim, data.sim$J)		
     }
    
        stu_covs_st1 <- scale(boot.dat[, unit.ms])
        sch_covs_st1 <- scale(boot.dat[,cluster.cov])
        
        try(bal1_st <- maxsubset_weights_cluster(stu_covs_st1, sch_covs_st1, boot.dat$Z, boot.dat$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose = FALSE))
                           
                           
       boot.dat$weights1 <- bal1_st$weights                       
       boot.dat$weights1[data.sim$weights1 < 0] <- 0                      
                           
   
     bounds_vbm_star  = estimate_vbm_bounds(c(0, par.unit.var), boot.dat$weights1, boot.dat$Z, boot.dat$Y, type = "ATO")
     bounds_msm_star = estimate_msm_bounds(c(1, par.unit.marg), boot.dat$weights1, boot.dat$Z, boot.dat$Y, type = "ATO")

      stu_covs_st2 <- scale(boot.dat[, unit.cov])
      sch_covs_st2 <- scale(boot.dat[,cluster.ms])
      try(bal3 <- maxsubset_weights_cluster(stu_covs_st2, sch_covs_st2, boot.dat$Z, boot.dat$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose = FALSE))
  
       boot.dat$weights2 <- bal3$weights                       
       boot.dat$weights2[data.sim$weights2 < 0] <- 0
       
bounds_vbm_star2  = estimate_vbm_bounds(c(0, par.clus.var), boot.dat$weights2, boot.dat$Z, boot.dat$Y, type = "ATO")
bounds_msm_star2 = estimate_msm_bounds(c(1, par.clus.marg), boot.dat$weights2, boot.dat$Z, boot.dat$Y, type = "ATO")
               
    out.boot.1[j,1] <- bounds_vbm_star[1,2]    
    out.boot.1[j,2] <- bounds_vbm_star[2,1]
    out.boot.1[j,3] <- bounds_vbm_star[2,2]
    
    out.boot.2[j,1] <- bounds_msm_star[1,2]
    out.boot.2[j,2] <- bounds_msm_star[2,1]
    out.boot.2[j,3] <- bounds_msm_star[2,2]
    
    out.boot.3[j,1] <- bounds_vbm_star2[1,2]
    out.boot.3[j,2] <- bounds_vbm_star2[2,1]
    out.boot.3[j,3] <- bounds_vbm_star2[2,2]
    
    out.boot.4[j,1] <- bounds_msm_star2[1,2]
    out.boot.4[j,2] <- bounds_msm_star2[2,1]
    out.boot.4[j,3] <- bounds_msm_star2[2,2]                                  
   }
   
   
# Save Boot Results
    out.wgt.star.1[i,1] <- mean(out.boot.1[,1], na.rm=TRUE)    
    out.wgt.star.1[i,2] <- mean(out.boot.1[,2], na.rm=TRUE)
    out.wgt.star.1[i,3] <- mean(out.boot.1[,3], na.rm=TRUE)
    
    out.wgt.star.2[i,1] <- mean(out.boot.2[,1], na.rm=TRUE)
    out.wgt.star.2[i,2] <- mean(out.boot.2[,2], na.rm=TRUE)
    out.wgt.star.2[i,3] <- mean(out.boot.2[,3], na.rm=TRUE)
    
    out.wgt.star.3[i,1] <- mean(out.boot.3[,1], na.rm=TRUE)
    out.wgt.star.3[i,2] <- mean(out.boot.3[,2], na.rm=TRUE)
    out.wgt.star.3[i,3] <- mean(out.boot.3[,3], na.rm=TRUE)
    
    out.wgt.star.4[i,1] <- mean(out.boot.4[,1], na.rm=TRUE)
    out.wgt.star.4[i,2] <- mean(out.boot.4[,2], na.rm=TRUE)
    out.wgt.star.4[i,3] <- mean(out.boot.4[,3], na.rm=TRUE) 

}


   
# simulation summaries   

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

# School Omitted
o3 <- apply(out.wgt.3, 2, mean, na.rm=TRUE)
o4 <- apply(out.wgt.4, 2, mean, na.rm=TRUE)

o1
o2
o3
o4

apply(out.wgt.star.1, 2, mean, na.rm=TRUE)
apply(out.wgt.star.2, 2, mean, na.rm=TRUE)
apply(out.wgt.star.3, 2, mean, na.rm=TRUE)
apply(out.wgt.star.4, 2, mean, na.rm=TRUE)


mean(as.numeric((out.wgt.1[,2] < treat.true) & (treat.true < out.wgt.1[,3])))
mean(as.numeric((out.wgt.2[,2] < treat.true) & (treat.true < out.wgt.2[,3])))
mean(as.numeric((out.wgt.3[,2] < treat.true) & (treat.true < out.wgt.3[,3])))
mean(as.numeric((out.wgt.4[,2] < treat.true) & (treat.true < out.wgt.4[,3])))


mean(as.numeric((out.wgt.star.1[,2] < out.wgt.1[,2]) & (out.wgt.1[,3] < out.wgt.star.1[,3])))
mean(as.numeric((out.wgt.star.2[,2] < out.wgt.2[,2]) & (out.wgt.2[,2] < out.wgt.star.2[,3])))
mean(as.numeric((out.wgt.star.3[,2] < out.wgt.3[,2]) & (out.wgt.3[,2] < out.wgt.star.3[,3])))
mean(as.numeric((out.wgt.star.4[,2] < out.wgt.4[,2]) & (out.wgt.4[,2] < out.wgt.star.4[,3])))


setwd("~/Dropbox/Group Matches/Analysis/Simulation/Sens/Alt-DGP/Boot")
save(out.wgt.1, out.wgt.2, out.wgt.3, out.wgt.4, 
     out.wgt.star.1, out.wgt.star.2, out.wgt.star.3, out.wgt.star.4,
     treat.true, file ="Sim-Sens-Boot-ATO.RData")	
     
     
     
     
     