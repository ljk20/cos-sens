

library(MASS)
library(dplyr)


rm(list=ls())

source("functions.R")

#Covariate Lists
bal.cov <- c("cluster.x1", "cluster.x2", "h1", "h2",
             "h3", "h4", "x1", "x2", "x3", "x4", "x5")
             
             
school.cov <- c("cluster.x1", "cluster.x2", "h1", "h2", "h3", "h4")
student.cov <- c("x1", "x2", "x3", "x4", "x5")

unit.ms <- c("x1", "x2", "x3", "x4")
cluster.ms <- c("cluster.x1", "cluster.x2", "h2", "h3", "h4")

#### parameters ####
#n_rep<-1
#n.boot<-1000
#alpha<-0.05
#tau <- 0.16

nsim <- 1000
data <- data_gen("tt3", I = 50, N = 5000)

set.seed(12387474)

out.var.unit <- matrix(NA, nsim, 1)
out.marg.unit <- matrix(NA, nsim, 1)
out.var.clus <- matrix(NA, nsim, 1)
out.marg.clus <- matrix(NA, nsim, 1)

# Simulations
  for(i in 1:nsim){ 
  	  	
data.sim <- data_gen("tt3", I = 150, N = 5000)    
    
## Estimate Propensity Scores
## Process Weights
 psmod.oracle <- glm(reformulate(bal.cov, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$o.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.oracle$linear.predictors), 1)
 data.sim$o.wts[data.sim$Z==0] = data.sim$o.wts.p[data.sim$Z==0]/mean(data.sim$o.wts.p[data.sim$Z==0])
 summary(data.sim$o.wts)
 
 
 psmod.unit.ms <- glm(reformulate(unit.ms, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$u.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.unit.ms$linear.predictors), 1)
 data.sim$u.wts[data.sim$Z==0] = data.sim$u.wts.p[data.sim$Z==0]/mean(data.sim$u.wts.p[data.sim$Z==0])
summary(data.sim$u.wts)
 
 psmod.clus.ms <- glm(reformulate(cluster.ms, response = "Z"), 
                 family = binomial(), data = data.sim)
 data.sim$c.wts.p <- ifelse(data.sim$Z == 0, exp(psmod.clus.ms$linear.predictors), 1) 
 data.sim$c.wts[data.sim$Z==0] = data.sim$c.wts.p[data.sim$Z==0]/mean(data.sim$c.wts.p[data.sim$Z==0])
 summary(data.sim$c.wts)
  
# Save Results
    out.var.unit[i] <- 1 - (var(data.sim$u.wts[data.sim$Z==0])/var(data.sim$o.wts[data.sim$Z==0]))
    out.marg.unit[i] <- max(max(data.sim$o.wts[data.sim$Z==0]/data.sim$u.wts[data.sim$Z==0]), max(data.sim$u.wts[data.sim$Z==0]/data.sim$o.wts[data.sim$Z==0]))
    out.var.clus[i] <- 1 - (var(data.sim$c.wts[data.sim$Z==0])/var(data.sim$o.wts[data.sim$Z==0]))
    out.marg.clus[i] <- max(max(data.sim$o.wts[data.sim$Z==0]/data.sim$c.wts[data.sim$Z==0]), max(data.sim$c.wts[data.sim$Z==0]/data.sim$o.wts[data.sim$Z==0]))

   cat("Simulation: ", i, "\n") 
   }
   
    par.unit.var <- median(out.var.unit, na.rm=TRUE)
    par.unit.marg <- quantile(out.marg.unit, prob = .2, na.rm=TRUE)
    par.clus.var <- mean(out.var.clus, na.rm=TRUE)
    par.clus.marg <- quantile(out.marg.clus, prob = .2, na.rm=TRUE)
    
    par.unit.var 
    par.unit.marg 
    par.clus.var 
    par.clus.marg 
    
save(par.unit.var, 
    par.unit.marg, 
    par.clus.var, 
    par.clus.marg, file ="Sens-Parameters.RData")	
