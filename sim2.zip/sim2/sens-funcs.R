

estimate_zbs_bounds<-function(weights, Y, lambda){
  #Optimization procedure
  weights = weights[order(-Y)]
  Y = Y[order(-Y)]
  num_high = (weights*lambda)*Y
  num_low = (weights/lambda)*Y
  den_high = weights*lambda
  den_low = weights/lambda
  
  den = c(0, cumsum(den_high)) + c(rev(cumsum(rev(den_low))), 0)
  num = c(0, cumsum(num_high)) + c(rev(cumsum(rev(num_low))), 0)
  Y_max = max(num/den)
  Y_max_unnorm = max(num)/length(weights)
  cutoff_max = which.max(num/den)
  cutoff_max_unnorm = which.max(num)
  
  den = c(0, cumsum(den_low)) + c(rev(cumsum(rev(den_high))), 0)
  num = c(0, cumsum(num_low)) + c(rev(cumsum(rev(num_high))), 0)
  Y_min = min(num/den)
  
  return(data.frame(min = Y_min, max = Y_max))
}

estimate_vbm_bounds<-function(R2, weights, Z, Y, type = "ATT"){
  mu1 = mean(Y[Z==1]*weights[Z==1])/mean(weights[Z==1])
  mu0 = mean(Y[Z==0]*weights[Z==0])/mean(weights[Z==0])
  cor1_bound = sqrt(1-cor(weights[Z==1], Y[Z==1])^2)
  cor0_bound = sqrt(1-cor(weights[Z==0], Y[Z==0])^2)
  if(type == "ATO"){
    Y1_bias = cor1_bound*sqrt(var(weights[Z==1])*(R2/(1-R2))*var(Y[Z==1]))
    Y0_bias = cor0_bound*sqrt(var(weights[Z==0])*(R2/(1-R2))*var(Y[Z==0]))  
  }else if(type == "ATT"){
    Y1_bias = 0
    Y0_bias = cor0_bound*sqrt(var(weights[Z==0])*(R2/(1-R2))*var(Y[Z==0]))  
  }
  
  return(data.frame(min = (mu1-Y1_bias) - (mu0+Y0_bias), max = (mu1+Y1_bias) - (mu0-Y0_bias)))
}



estimate_msm_bounds<-function(lambda, weights, Z, Y, type = "ATT"){
  if(length(lambda) > 1){
    mu1_bounds = lapply(lambda, estimate_zbs_bounds, weights = weights[Z==1], Y = Y[Z==1]) |> dplyr::bind_rows()
    mu0_bounds = lapply(lambda, estimate_zbs_bounds, weights = weights[Z==0], Y = Y[Z==0]) |> dplyr::bind_rows()
  }else{
    mu1_bounds = estimate_zbs_bounds(weights[Z==1], Y[Z==1], lambda)
    mu0_bounds = estimate_zbs_bounds(weights[Z==0], Y[Z==0], lambda)  
  }
  
  
  if(type == "ATO"){
    maxValue = mu1_bounds$max - mu0_bounds$min
    minValue = mu1_bounds$min - mu0_bounds$max  
  }else if(type == "ATT"){
    mu1 = mean(Y[Z==1]*weights[Z==1])/mean(weights[Z==1])
    maxValue = mu1 - mu0_bounds$min
    minValue = mu1 - mu0_bounds$max
  }
  
  return(data.frame(min = minValue, max = maxValue))
}
