
library(MASS)
library(dplyr)


data_gen<-function(case=c("tt1","tt2","tt3"), I, N){
  if(case=="tt1"){ # Target trial 1: subject-cluster pairing first
    
    x1=rnorm(N)
    x2=rbinom(N,1,0.4)
    mu=rep(0, 3) 
    var.cov.matrix=matrix(c(2, 1, -1, 1, 1, -0.5, -1, -0.5, 1), nrow=3, ncol=3)
    C = mvrnorm(n=N, mu=mu, Sigma=var.cov.matrix)
    x3 <- C[,1]
    x4 <- C[,2]
    x5 <- C[,3]
    chisq.df=1
    
    tmp<-rnorm(I)
    cluster.data<-data.frame(cluster.id=1:I, cluster.x1=tmp, cluster.x2=tmp*.5+rnorm(I))
    data<-data.frame(x1=x1, x2=x2, x3=x3, x4=x4, x5=x5)
    
    sel.prob<-matrix(data=0,nrow=N,ncol=I)
    for(i in 1:I){
      sel.prob[,i]<-exp((0.1*cluster.data$cluster.x1[i] + 0.1*cluster.data$cluster.x2[i])*(1+data$x1+data$x2+data$x3+data$x4+data$x5))
      
    }
    sel.prob<-t(apply(sel.prob,1,function(x)(x/sum(x))))
    data$cluster.id<-Hmisc::rMultinom(sel.prob,m=1)
    full.data<-merge(cluster.data, data, by="cluster.id")
    
    full.data.summary<-full.data %>% 
      group_by(cluster.id) %>%
      summarize(cluster.x1=mean(cluster.x1), cluster.x2=mean(cluster.x2), h1=quantile(x1,0.25),
                h2=quantile(x1,0.5),h3=quantile(x1,0.75),h4=mean(x2),m1=mean(x1))%>%
      ungroup()
    
    full.data.summary<-full.data.summary %>%
      mutate(treat=rbinom(I,1,exp(0.2*cluster.x1+0.1*cluster.x2+.2*(h1+h2+h3)+0.2*(h4-0.4))/
                            (1+exp(0.2*cluster.x1+0.1*cluster.x2+.2*(h1+h2+h3)+0.2*(h4-0.4)))))
    
    full.data<-merge(full.data.summary,data,by="cluster.id")
    cluster.random<-rnorm(I)
    full.data<-full.data%>% 
      mutate(y=x1+x2+x3+x4+x5+0.4*treat*(x1+x2)+0.5*(cluster.x1+h1+h2+h3+h4)+0.1*cluster.random[cluster.id]+ rnorm(N))
    
    
  }else if(case=="tt2"){ # Target trial 2: cluster treatment assignment first, with BLINDED subject-cluster pairing
    
    x1=rnorm(N)
    x2=rbinom(N,1,0.4)
    mu=rep(0, 3) 
    var.cov.matrix=matrix(c(2, 1, -1, 1, 1, -0.5, -1, -0.5, 1), nrow=3, ncol=3)
    C = mvrnorm(n=N, mu=mu, Sigma=var.cov.matrix)
    x3 <- C[,1]
    x4 <- C[,2]
    x5 <- C[,3]
    chisq.df=1
    
    tmp<-rnorm(I)
    cluster.data<-data.frame(J=1:I, cluster.x1=tmp, cluster.x2=tmp*.5+rnorm(I))
    cluster.data <- cluster.data %>% mutate(Z=rbinom(I,1,exp(0.2*cluster.x1+0.1*cluster.x2)/(1+exp(0.2*cluster.x1+0.1*cluster.x2))))
    
    data <- data.frame(x1=x1, x2=x2, x3=x3, x4=x4, x5=x5)
    sel.prob<-matrix(data=0,nrow=N,ncol=I)
    for(i in 1:I){
      sel.prob[,i]<-exp((0.1*cluster.data$cluster.x1[i] + 0.1*cluster.data$cluster.x2[i])*(1+data$x1+data$x2+data$x3+data$x4+data$x5))
    }
    
    sel.prob<-t(apply(sel.prob,1,function(x)(x/sum(x))))
    data$J<-Hmisc::rMultinom(sel.prob,m=1)
    full.data<-merge(cluster.data,data,by="J")
    
    full.data.summary<-full.data %>% 
      group_by(J) %>%
      summarize(Z = mean(Z), cluster.x1=mean(cluster.x1), cluster.x2=mean(cluster.x2), h1=quantile(x1,0.25),
                h2=quantile(x1,0.5),h3=quantile(x1,0.75),h4=mean(x2))%>%
      ungroup()
    
    full.data<-merge(full.data.summary, data, by="J")
    cluster.random<-rnorm(I)
    
    full.data<-full.data%>% 
      mutate(Y=x1+x2+x3+x4+x5+0.4*Z*(x1+x2)+0.5*(cluster.x1+h1+h2+h3+h4)+0.1*cluster.random[cluster.id]+ rnorm(N))
    
  }else if(case=="tt3"){ # Target trial 3: cluster treatment assignment first, with UNBLINDED subject-cluster pairing
    
    x1=rnorm(N)
    x2=rbinom(N,1,0.4)
    mu=rep(0, 3) 
    var.cov.matrix=matrix(c(2, 1, -1, 1, 1, -0.5, -1, -0.5, 1), nrow=3, ncol=3)
    C = mvrnorm(n=N, mu=mu, Sigma=var.cov.matrix)
    x3 <- C[,1]
    x4 <- C[,2]
    x5 <- C[,3]
    chisq.df=1
    
    tmp<-rnorm(I)
    cluster.data<-data.frame(J=1:I, cluster.x1=tmp, cluster.x2=tmp*.5+rnorm(I))
    cluster.data<-cluster.data %>% mutate(Z=rbinom(I,1,exp(0.2*cluster.x1 + 0.1*cluster.x2)/(1+exp(0.2*cluster.x1+ 0.1*cluster.x2))))
    data<-data.frame(x1=x1, x2=x2, x3=x3, x4=x4, x5=x5)
    sel.prob<-matrix(data=0,nrow=N,ncol=I)
    
    for(i in 1:I){
      sel.prob[,i]<-exp((0.1*cluster.data$cluster.x1[i] + .01*cluster.data$cluster.x2[i])*(1+data$x1+data$x2+data$x3+data$x4+data$x5)+
                          0.2*cluster.data$Z[i]*(1+data$x1+data$x2))
    }
    
    sel.prob<-t(apply(sel.prob,1,function(x)(x/sum(x))))
    data$J <- Hmisc::rMultinom(sel.prob,m=1)
    full.data<-merge(cluster.data,data,by="J")
    
    full.data.summary<-full.data %>% 
      group_by(J) %>%
      summarize(Z = mean(Z), cluster.x1=mean(cluster.x1), cluster.x2=mean(cluster.x2), h1=quantile(x1,0.25),
                h2=quantile(x1,0.5),h3=quantile(x1,0.75), h4=mean(x2))%>%
      ungroup()
    
    full.data<-merge(full.data.summary,data,by="J")
    cluster.random<-rnorm(I)
    full.data<-full.data%>% 
      mutate(Y=x1+x2+x3+x4+x5+0.4*Z*(x1+x2)+0.5*(cluster.x1+h1+h2+h3+h4)+0.1*cluster.random[J]+ rnorm(N))
  }
  return(full.data)
}

g_comp<-function(data,adj=c("adj.w","adj.wh","adj.whx")){
  if(adj=="adj.w"){
    fit1<-lm(y~cluster.x1 + cluster.x2,data=data[data$treat==1,])
    fit0<-lm(y~cluster.x1 + cluster.x2,data=data[data$treat==0,])
  }else if(adj=="adj.wh"){
    fit1<-lm(y ~ cluster.x1 + cluster.x2+h1+h2+h3+h4,data=data[data$treat==1,])
    fit0<-lm(y ~ cluster.x1 + cluster.x2+h1+h2+h3+h4,data=data[data$treat==0,])
  }else if(adj=="adj.whx"){
    fit1<-lm(y~cluster.x1+cluster.x2+h1+h2+h3+h4+x1+x2+x3+x4+x5,data=data[data$treat==1,])
    fit0<-lm(y~cluster.x1+cluster.x2+h1+h2+h3+h4+x1+x2+x3+x4+x5,data=data[data$treat==0,])
  }
  pred1<-predict(fit1,data)
  pred0<-predict(fit0,data)
  tau<-mean(pred1)-mean(pred0)
  return(tau)
}

